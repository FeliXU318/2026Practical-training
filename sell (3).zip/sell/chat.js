// utils/api/chat.js
// 聊天接口：会话列表、消息历史、发送消息、好友搜索、好友列表
const { http, USE_MOCK, mockDelay } = require('../request.js')

// ===== 会话相关 =====

// 获取会话列表（含客服会话）
function getSessions() {
  if (USE_MOCK) {
    const sessions = wx.getStorageSync('chat_sessions') || []
    return mockDelay({ list: sessions })
  }
  // 真实接口：GET /chat/sessions，token 自动带
  return http.get('/chat/sessions')
}

// 创建或进入私聊会话
// targetId: 对方用户ID
function createOrGetSession(targetId) {
  if (USE_MOCK) {
    const sessions = wx.getStorageSync('chat_sessions') || []
    const sessionId = `user_${targetId}`
    let session = sessions.find(s => s.id === sessionId)
    if (!session) {
      session = {
        id: sessionId,
        type: 'user',
        targetId,
        targetName: `用户${targetId}`,
        targetAvatar: '',
        lastMessage: '开始聊天吧',
        lastTime: formatTime(new Date()),
        unread: 0
      }
      sessions.unshift(session)
      wx.setStorageSync('chat_sessions', sessions)
      wx.setStorageSync(`chat_messages_${sessionId}`, [])
    }
    return mockDelay(session)
  }
  // 真实接口：POST /chat/session
  return http.post('/chat/session', { targetId })
}

// 删除会话
function deleteSession(sessionId) {
  if (USE_MOCK) {
    let sessions = wx.getStorageSync('chat_sessions') || []
    sessions = sessions.filter(s => s.id !== sessionId)
    wx.setStorageSync('chat_sessions', sessions)
    wx.removeStorageSync(`chat_messages_${sessionId}`)
    return mockDelay({ success: true })
  }
  return http.delete('/chat/session', { sessionId })
}

// 标记会话已读
function markRead(sessionId) {
  if (USE_MOCK) {
    const sessions = wx.getStorageSync('chat_sessions') || []
    const session = sessions.find(s => s.id === sessionId)
    if (session && session.unread > 0) {
      session.unread = 0
      wx.setStorageSync('chat_sessions', sessions)
    }
    return mockDelay({ success: true })
  }
  return http.post('/chat/read', { sessionId })
}

// ===== 消息相关 =====

// 获取历史消息（分页）
function getMessages(sessionId, page = 1, size = 20) {
  if (USE_MOCK) {
    const messages = wx.getStorageSync(`chat_messages_${sessionId}`) || []
    return mockDelay({ list: messages, hasMore: false })
  }
  return http.get('/chat/messages', { sessionId, page, size })
}

// 发送文字消息
function sendTextMessage(sessionId, receiverId, content) {
  if (USE_MOCK) {
    const key = `chat_messages_${sessionId}`
    const messages = wx.getStorageSync(key) || []
    const msg = {
      id: genId(),
      sessionId,
      senderId: getMyUserId(),
      receiverId,
      content,
      type: 'text',
      from: 'me',
      time: formatTime(new Date())
    }
    messages.push(msg)
    wx.setStorageSync(key, messages)
    // 更新会话
    updateSessionLastMessage(sessionId, content)
    return mockDelay(msg)
  }
  return http.post('/chat/send', {
    sessionId, receiverId, content, type: 'text'
  })
}

// 发送图片消息（先上传图片拿URL，再发消息）
function sendImageMessage(sessionId, receiverId, imageUrl) {
  if (USE_MOCK) {
    const key = `chat_messages_${sessionId}`
    const messages = wx.getStorageSync(key) || []
    const msg = {
      id: genId(),
      sessionId,
      senderId: getMyUserId(),
      receiverId,
      content: imageUrl,
      type: 'image',
      from: 'me',
      time: formatTime(new Date())
    }
    messages.push(msg)
    wx.setStorageSync(key, messages)
    updateSessionLastMessage(sessionId, '[图片]')
    return mockDelay(msg)
  }
  return http.post('/chat/send', {
    sessionId, receiverId, content: imageUrl, type: 'image'
  })
}

// 发送表情消息
function sendEmojiMessage(sessionId, receiverId, emoji) {
  if (USE_MOCK) {
    const key = `chat_messages_${sessionId}`
    const messages = wx.getStorageSync(key) || []
    const msg = {
      id: genId(),
      sessionId,
      senderId: getMyUserId(),
      receiverId,
      content: emoji,
      type: 'emoji',
      from: 'me',
      time: formatTime(new Date())
    }
    messages.push(msg)
    wx.setStorageSync(key, messages)
    updateSessionLastMessage(sessionId, emoji)
    return mockDelay(msg)
  }
  return http.post('/chat/send', {
    sessionId, receiverId, content: emoji, type: 'emoji'
  })
}

// ===== 用户搜索 =====

function searchUser(keyword) {
  if (USE_MOCK) {
    // mock：生成一些虚拟用户
    const mockUsers = [
      { userId: 1001, nickName: '小明', phone: '13800138001', avatarUrl: '/images/default-avatar.png' },
      { userId: 1002, nickName: '小红', phone: '13800138002', avatarUrl: '/images/default-avatar.png' },
      { userId: 1003, nickName: '小华', phone: '13800138003', avatarUrl: '/images/default-avatar.png' }
    ]
    const result = mockUsers.filter(u =>
      String(u.userId) === keyword || u.phone === keyword
    )
    return mockDelay({ list: result })
  }
  return http.get('/chat/search', { keyword })
}

// ===== 辅助函数 =====

function formatTime(date) {
  const h = String(date.getHours()).padStart(2, '0')
  const m = String(date.getMinutes()).padStart(2, '0')
  return `${h}:${m}`
}

function genId() {
  return Date.now() + '' + Math.floor(Math.random() * 1000)
}

function getMyUserId() {
  const userInfo = wx.getStorageSync('userInfo') || {}
  return userInfo.userId || 0
}

// 更新会话最后消息（mock 内部用）
function updateSessionLastMessage(sessionId, content) {
  const sessions = wx.getStorageSync('chat_sessions') || []
  const session = sessions.find(s => s.id === sessionId)
  if (session) {
    session.lastMessage = content
    session.lastTime = formatTime(new Date())
    wx.setStorageSync('chat_sessions', sessions)
  }
}

module.exports = {
  getSessions,
  createOrGetSession,
  deleteSession,
  markRead,
  getMessages,
  sendTextMessage,
  sendImageMessage,
  sendEmojiMessage,
  searchUser
}
