package com.cqu.sell.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.*;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@TableName("cart")
public class cart {
    @TableId(value="id",type=IdType.AUTO)
    private Integer id;

    @TableField(value="user_id")
    private String userId;

    @TableField(value="cart_key")
    private String cartKey;

    @TableField(value="product_id")
    private Integer productId;

    private String name;
    private Double price;
    private String image;
    private Integer quantity;
}