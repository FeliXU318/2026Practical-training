package com.cqu.sell.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.*;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@TableName("chat_session")
public class chatSession {

    @TableId(value="session_id",type=IdType.AUTO)
    private Integer sessionId;

    @TableField(value="session_key")
    private String sessionKey;

    @TableField(value="user_id")
    private Integer userId;

    @TableField(value="target_id")
    private Integer targetId;

    @TableField(value="target_name")
    private String targetName;

    @TableField(value="target_avatar")
    private String targetAvatar;

    @TableField(value="last_message")
    private String lastMessage;

    @TableField(value="last_time")
    private String lastTime;

    private Integer unread;

    private String type;

    @TableField(value="create_time")
    private String createTime;

    @TableField(value="update_time")
    private String updateTime;

}