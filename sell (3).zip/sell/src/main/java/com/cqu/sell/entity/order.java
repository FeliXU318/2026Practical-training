package com.cqu.sell.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.*;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@TableName("orders")
public class order {
    @TableId(value="order_id",type=IdType.AUTO)
    private Integer orderId;

    @TableField(value="user_id")
    private Integer userId;

    @TableField(value="merchant_id")
    private Integer merchantId;

    @TableField(value="order_type")
    private String orderType;

    @TableField(value="total_amount")
    private double totalAmount;

    @TableField(value="deliver_type")
    private String deliverType;

    @TableField(value="order_status")
    private String orderStatus;

    @TableField(value="phone")
    private String phone;

    private String address;
    private String title;
    private String content;
    private double reward;

    @TableField(value="status_class")
    private String statusClass;
    private String time;
    private String location;
    private String color;
    private Boolean rewarded;

    @TableField(value="after_sale_id")
    private String afterSaleId;
}
