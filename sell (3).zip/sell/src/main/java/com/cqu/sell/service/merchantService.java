package com.cqu.sell.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.cqu.sell.entity.merchant;
import com.baomidou.mybatisplus.extension.service.IService;
import java.util.List;
import java.util.Map;

public interface merchantService extends IService<merchant>{
    List<merchant> findAll();

    List<merchant> findMerchantByType(String merchantType);

    List<merchant> findMerchantByName(String merchantName);

    boolean addMerchant(merchant merchant);

    boolean deleteMerchant(int merchant_id);

    boolean updateMerchantName(int merchant_id, String merchant_name);

    boolean updateContactPhone(int merchant_id, String contact_phone);

    boolean updateStatus(int merchant_id, String status);

    IPage<merchant> getMerchantPage(long current, long size);

    Map<String, Object> login(String account, String password, String dormBuilding, String merchantCategory);

    Map<String, Object> wechatLogin(String code);

    Map<String, Object> bindPhone(String loginToken, String phoneCode, String businessType, String merchantCategory);

    merchant getMerchantByBusinessType(String businessType);

}
