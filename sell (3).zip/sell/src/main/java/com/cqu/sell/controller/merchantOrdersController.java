package com.cqu.sell.controller;

import com.cqu.sell.entity.order;
import com.cqu.sell.entity.product;
import com.cqu.sell.entity.user;
import com.cqu.sell.mapper.orderMapper;
import com.cqu.sell.mapper.productMapper;
import com.cqu.sell.mapper.userMapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/merchant/orders")
public class merchantOrdersController {

    @Autowired
    private orderMapper orderMapper;
    
    @Autowired
    private productMapper productMapper;

    @Autowired
    private userMapper userMapper;

    @GetMapping
    public Map<String, Object> list(@RequestParam String businessType, 
                                    @RequestParam(required = false) String merchantCategory,
                                    @RequestParam Integer merchantId,
                                    @RequestParam(required = false) String status) {
        Map<String, Object> result = new HashMap<>();
        QueryWrapper<order> wrapper = new QueryWrapper<>();
        
        if (merchantId != null) {
            wrapper.eq("merchant_id", merchantId);
        }
        
        if (status != null && !"all".equals(status)) {
            if ("pending".equals(status)) {
                wrapper.in("status_class", "status-pending", "status-pay", "status-ship");
            } else if ("preparing".equals(status)) {
                wrapper.eq("status_class", "status-preparing");
            } else if ("ready".equals(status)) {
                wrapper.eq("status_class", "status-ready");
            } else if ("delivery".equals(status)) {
                wrapper.eq("status_class", "status-delivering");
            } else if ("completed".equals(status)) {
                wrapper.eq("status_class", "status-done");
            }
        } else {
            wrapper.notIn("status_class", "status-cancelled");
        }
        
        wrapper.orderByDesc("order_id");
        List<order> orders = orderMapper.selectList(wrapper);
        
        List<Map<String, Object>> list = new ArrayList<>();
        for (order o : orders) {
            Map<String, Object> item = new HashMap<>();
            item.put("id", o.getOrderId());
            item.put("orderNo", "O" + String.format("%010d", o.getOrderId()));
            item.put("businessType", businessType);
            Integer userId = o.getUserId();
            String displayUserId = (userId != null) ? userId.toString() : "未知";
            item.put("customer", "用户" + displayUserId);
            item.put("phone", o.getPhone());
            item.put("dorm", "");
            item.put("deliveryMethod", "pickup");
            item.put("deliveryText", "客户自提");
            item.put("pickupCode", String.format("%06d", o.getOrderId() % 1000000));
            item.put("reserveTime", "今天");
            item.put("status", getStatusCode(o.getStatusClass()));
            item.put("statusText", getStatusText(o.getStatusClass()));
            item.put("amount", o.getTotalAmount());
            item.put("discount", 0);
            item.put("remark", o.getContent());
            item.put("createdAt", o.getTime());
            
            List<Map<String, Object>> items = new ArrayList<>();
            Map<String, Object> orderItem = new HashMap<>();
            orderItem.put("name", o.getTitle());
            orderItem.put("count", 1);
            orderItem.put("price", o.getTotalAmount());
            items.add(orderItem);
            item.put("items", items);
            
            list.add(item);
        }
        
        result.put("code", 0);
        result.put("message", "ok");
        result.put("data", list);
        return result;
    }

    @GetMapping("/{id}")
    public Map<String, Object> detail(@PathVariable Integer id, @RequestParam(required = false) Integer merchantId) {
        Map<String, Object> result = new HashMap<>();
        order o = orderMapper.selectById(id);

        Integer user_id = o.getUserId();

        user u= userMapper.selectById(user_id);
        String name = u.getNickname();
        
        if (o != null && (merchantId == null || merchantId.equals(o.getMerchantId()))) {
            Map<String, Object> data = new HashMap<>();
            data.put("id", o.getOrderId());
            data.put("orderNo", "O" + String.format("%010d", o.getOrderId()));
            data.put("businessType", "");
            Integer userId = o.getUserId();
            String displayUserId = (userId != null) ? userId.toString() : "未知";
            data.put("customer", name);
            data.put("phone", o.getPhone());
            data.put("dorm", o.getAddress());
            data.put("deliveryMethod", "pickup");
            data.put("deliveryText", "客户自提");
            data.put("pickupCode", String.format("%06d", o.getOrderId() % 1000000));
            data.put("reserveTime", "今天");
            data.put("status", getStatusCode(o.getStatusClass()));
            data.put("statusText", getStatusText(o.getStatusClass()));
            data.put("amount", o.getTotalAmount());
            data.put("discount", 0);
            data.put("remark", o.getContent());
            data.put("createdAt", o.getTime());
            
            List<Map<String, Object>> items = new ArrayList<>();
            Map<String, Object> orderItem = new HashMap<>();
            orderItem.put("name", o.getTitle());
            orderItem.put("count", 1);
            orderItem.put("price", o.getTotalAmount());
            items.add(orderItem);
            data.put("items", items);
            
            result.put("code", 0);
            result.put("message", "ok");
            result.put("data", data);
        } else {
            result.put("code", 1);
            result.put("message", "订单不存在");
        }
        
        return result;
    }

    @PatchMapping("/status")
    public Map<String, Object> updateStatus(@RequestBody Map<String, Object> body) {
        Map<String, Object> result = new HashMap<>();
        Integer id = ((Number) body.get("id")).intValue();
        String newStatus = (String) body.get("status");
        Object merchantIdObj = body.get("merchantId");
        Integer merchantId = merchantIdObj != null ? ((Number) merchantIdObj).intValue() : null;
        
        order o = orderMapper.selectById(id);
        if (o != null && (merchantId == null || merchantId.equals(o.getMerchantId()))) {
            switch (newStatus) {
                case "preparing":
                    o.setOrderStatus("备货中");
                    o.setStatusClass("status-preparing");
                    break;
                case "ready":
                    o.setOrderStatus("待自提");
                    o.setStatusClass("status-ready");
                    break;
                case "delivery":
                    o.setOrderStatus("配送中");
                    o.setStatusClass("status-delivering");
                    break;
                case "completed":
                    deductStock(o);
                    o.setOrderStatus("已完成");
                    o.setStatusClass("status-done");
                    break;
            }
            
            orderMapper.updateById(o);
            
            Map<String, Object> data = new HashMap<>();
            data.put("id", o.getOrderId());
            data.put("status", getStatusCode(o.getStatusClass()));
            data.put("statusText", getStatusText(o.getStatusClass()));
            
            result.put("code", 0);
            result.put("message", "ok");
            result.put("data", data);
        } else {
            result.put("code", 1);
            result.put("message", "订单不存在");
        }
        
        return result;
    }

    private void deductStock(order o) {
        if ("status-done".equals(o.getStatusClass())) {
            return;
        }
        String content = o.getContent();
        if (content == null || content.isEmpty()) {
            return;
        }

        Integer merchantId = o.getMerchantId();

        List<Map<String, Object>> items = parseOrderContent(content);
        for (Map<String, Object> item : items) {
            String productName = (String) item.get("name");
            Integer quantity = (Integer) item.get("quantity");
            
            if (productName != null && !productName.isEmpty()) {
                QueryWrapper<product> wrapper = new QueryWrapper<>();
                wrapper.eq("product_name", productName);
                if (merchantId != null) {
                    wrapper.eq("merchant_id", merchantId);
                }
                product p = productMapper.selectOne(wrapper);
                if (p != null) {
                    Integer stock = p.getStock() != null ? p.getStock() : 0;
                    if (stock >= quantity) {
                        p.setStock(stock - quantity);
                        p.setSales((p.getSales() != null ? p.getSales() : 0) + quantity);
                        productMapper.updateById(p);
                    }
                }
            }
        }
    }

    private List<Map<String, Object>> parseOrderContent(String content) {
        List<Map<String, Object>> items = new ArrayList<>();
        if (content == null || content.isEmpty()) {
            return items;
        }
        java.util.regex.Pattern pattern = java.util.regex.Pattern.compile("([^×，,]+)×(\\d+)");
        java.util.regex.Matcher matcher = pattern.matcher(content);
        while (matcher.find()) {
            String name = matcher.group(1).trim();
            Integer quantity = Integer.parseInt(matcher.group(2));
            Map<String, Object> item = new HashMap<>();
            item.put("name", name);
            item.put("quantity", quantity);
            items.add(item);
        }
        return items;
    }

    @PostMapping("/verify")
    public Map<String, Object> verify(@RequestBody Map<String, Object> body) {
        Map<String, Object> result = new HashMap<>();
        String code = (String) body.get("code");
        Object merchantIdObj = body.get("merchantId");
        Integer merchantId = merchantIdObj != null ? ((Number) merchantIdObj).intValue() : null;
        
        QueryWrapper<order> wrapper = new QueryWrapper<>();
        wrapper.eq("status_class", "status-ready");
        if (merchantId != null) {
            wrapper.eq("merchant_id", merchantId);
        }
        List<order> orders = orderMapper.selectList(wrapper);
        
        order found = null;
        for (order o : orders) {
            String expectedCode = String.format("%06d", o.getOrderId() % 1000000);
            if (expectedCode.equals(code)) {
                found = o;
                break;
            }
        }
        
        if (found != null) {
            deductStock(found);
            found.setOrderStatus("已完成");
            found.setStatusClass("status-done");
            orderMapper.updateById(found);
            
            Map<String, Object> data = new HashMap<>();
            data.put("id", found.getOrderId());
            data.put("orderNo", "O" + String.format("%010d", found.getOrderId()));
            data.put("status", "completed");
            data.put("statusText", "已完成");
            data.put("deliveryText", "客户自提");
            data.put("pickupCode", code);
            
            result.put("code", 0);
            result.put("message", "ok");
            result.put("data", data);
        } else {
            result.put("code", 1);
            result.put("message", "未找到对应客户自提订单");
        }
        
        return result;
    }

    private String getStatusCode(String statusClass) {
        if (statusClass == null) return "pending";
        return switch (statusClass) {
            case "status-preparing" -> "preparing";
            case "status-ready" -> "ready";
            case "status-delivering" -> "delivery";
            case "status-done" -> "completed";
            case "status-aftersale" -> "aftersale";
            case "status-cancelled" -> "cancelled";
            case "status-pay" -> "pending";
            case "status-ship" -> "pending";
            default -> "pending";
        };
    }

    private String getStatusText(String statusClass) {
        if (statusClass == null) return "待处理";
        return switch (statusClass) {
            case "status-preparing" -> "备货中";
            case "status-ready" -> "待客户自提";
            case "status-delivering" -> "配送中";
            case "status-done" -> "已完成";
            case "status-aftersale" -> "售后中";
            case "status-cancelled" -> "已取消";
            case "status-pay" -> "待支付";
            case "status-ship" -> "待处理";
            default -> "待处理";
        };
    }
}