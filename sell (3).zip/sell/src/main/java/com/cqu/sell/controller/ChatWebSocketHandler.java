package com.cqu.sell.controller;

import com.cqu.sell.entity.chat;
import com.cqu.sell.entity.chatSession;
import com.cqu.sell.mapper.chatMapper;
import com.cqu.sell.mapper.chatSessionMapper;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.socket.CloseStatus;
import org.springframework.web.socket.TextMessage;
import org.springframework.web.socket.WebSocketSession;
import org.springframework.web.socket.handler.TextWebSocketHandler;

import java.io.IOException;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

@Component
public class ChatWebSocketHandler extends TextWebSocketHandler {

    @Autowired
    private chatMapper chatMapper;

    private final Map<Integer, WebSocketSession> userSessions = new ConcurrentHashMap<>();

    @Override
    public void afterConnectionEstablished(WebSocketSession session) throws Exception {
        Integer userId = (Integer) session.getAttributes().get("userId");
        if (userId != null) {
            userSessions.put(userId, session);
        }
    }

    @Override
    protected void handleTextMessage(WebSocketSession session, TextMessage message) throws Exception {
        Integer userId = (Integer) session.getAttributes().get("userId");
        if (userId == null) {
            return;
        }

        String payload = message.getPayload();
        ObjectMapper mapper = new ObjectMapper();
        Map<String, Object> data = mapper.readValue(payload, Map.class);

        String action = (String) data.get("action");
        if ("send".equals(action)) {
            handleSendMessage(userId, data);
        } else if ("ping".equals(action)) {
            session.sendMessage(new TextMessage("{\"action\":\"pong\"}"));
        }
    }

    private void handleSendMessage(Integer senderId, Map<String, Object> data) {
        String sessionKey = (String) data.get("sessionKey");
        Object receiverIdObj = data.get("receiverId");
        String content = (String) data.get("content");
        String type = (String) data.get("type");

        if (sessionKey == null || receiverIdObj == null || content == null) {
            return;
        }

        Integer receiverId = ((Number) receiverIdObj).intValue();

        chat chatMsg = new chat();
        chatMsg.setSessionKey(sessionKey);
        chatMsg.setSenderId(senderId);
        chatMsg.setReceiverId(receiverId);
        chatMsg.setContent(content);
        chatMsg.setType(type != null ? type : "text");
        chatMsg.setIsRead(0);
        chatMsg.setTimestamp(System.currentTimeMillis());
        
        Date now = new Date();
        java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("HH:mm");
        chatMsg.setCreateTime(sdf.format(now));

        chatMapper.insert(chatMsg);

        WebSocketSession receiverSession = userSessions.get(receiverId);
        if (receiverSession != null && receiverSession.isOpen()) {
            try {
                Map<String, Object> response = new HashMap<>();
                response.put("action", "message");
                response.put("id", chatMsg.getChatId());
                response.put("sessionId", sessionKey);
                response.put("senderId", senderId);
                response.put("receiverId", receiverId);
                response.put("content", content);
                response.put("type", chatMsg.getType());
                response.put("time", chatMsg.getCreateTime());

                ObjectMapper mapper = new ObjectMapper();
                receiverSession.sendMessage(new TextMessage(mapper.writeValueAsString(response)));
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    public void afterConnectionClosed(WebSocketSession session, CloseStatus status) throws Exception {
        Integer userId = (Integer) session.getAttributes().get("userId");
        if (userId != null) {
            userSessions.remove(userId);
        }
    }

    public boolean isOnline(Integer userId) {
        WebSocketSession session = userSessions.get(userId);
        return session != null && session.isOpen();
    }

    public void sendToUser(Integer userId, String message) {
        WebSocketSession session = userSessions.get(userId);
        if (session != null && session.isOpen()) {
            try {
                session.sendMessage(new TextMessage(message));
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}