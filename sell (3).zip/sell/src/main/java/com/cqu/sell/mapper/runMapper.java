package com.cqu.sell.mapper;

import com.cqu.sell.entity.run;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface runMapper extends BaseMapper<run> {
}