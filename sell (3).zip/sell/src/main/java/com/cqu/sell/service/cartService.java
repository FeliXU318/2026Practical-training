package com.cqu.sell.service;

import com.cqu.sell.entity.cart;
import com.baomidou.mybatisplus.extension.service.IService;
import java.util.List;

public interface cartService extends IService<cart> {
    List<cart> getCartByUserAndKey(String userId, String cartKey);
    cart addToCart(String userId, String cartKey, Integer productId, String name, double price, String image);
    cart updateQuantity(String userId, String cartKey, Integer productId, Integer quantity);
    boolean clearCart(String userId, String cartKey);
}