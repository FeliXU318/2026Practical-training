package com.cqu.sell.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.cqu.sell.entity.user;
import com.cqu.sell.mapper.userMapper;
import com.cqu.sell.service.userService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class userServiceImpl extends ServiceImpl<userMapper, user> implements userService {

    @Override
    public boolean login(String phone,String password){

        QueryWrapper<user> wrapper = new QueryWrapper<>();
        wrapper.eq("phone",phone)
               .eq("password",password);

        return this.baseMapper.selectOne(wrapper) != null;

    }/**用户登录**/

    @Override
    public List<user> findAll(){

       QueryWrapper<user> wrapper =new QueryWrapper<>();
       return baseMapper.selectList(wrapper);

    }

    @Override
    public boolean register(user user){
       QueryWrapper<user> wrapper=new QueryWrapper<>();
       wrapper.eq("phone",user.getPhone());
       user u=baseMapper.selectOne(wrapper);
       if(u!=null){
           return false;
       }
       return this.save(user);
    }

    @Override
    public boolean deleteUser(int id){
        return this.removeById(id);
    }

    @Override
    public boolean updatePassword(int user_id,String password){
        user u = this.getById(user_id);
        String old_password=u.getPassword();
        if(!old_password.equals(password)){
            u.setPassword(password);
            this.updateById(u);
            return true;
        }
        else {return false;}
    }

    @Override
    public boolean updateNickname(int user_id,String nickname){
        user u = this.getById(user_id);
        String old_nickname=u.getNickname();
        if(!old_nickname.equals(nickname)){
            u.setNickname(nickname);
            this.updateById(u);
            return true;
        }
        else {return false;}
    }

    @Override
    public user getUserByPhone(String phone){
        QueryWrapper<user> wrapper=new QueryWrapper<>();
        wrapper.eq("phone",phone);
        user u=baseMapper.selectOne(wrapper);
        return u;
    }

    @Override
    public IPage<user> getUserPage(long current,long size){
        Page<user> page=new Page<>(current,size);
        QueryWrapper<user> wrapper=new QueryWrapper<>();
        wrapper.orderByAsc("user_id");
        return this.page(page,wrapper);
    }
}
