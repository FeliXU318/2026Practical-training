package com.cqu.sell.service;

import com.cqu.sell.entity.aftersale;
import com.baomidou.mybatisplus.extension.service.IService;
import java.util.List;

public interface aftersaleService extends IService<aftersale> {
    String apply(Integer userId, Integer orderId, String type, String reason, String reasonDesc, Double amount, String images, String description);
    List<aftersale> getList(Integer userId, String status);
    aftersale getDetail(String afterSaleId);
    boolean cancel(String afterSaleId);
    boolean ship(String afterSaleId, String company, String trackingNo);
}