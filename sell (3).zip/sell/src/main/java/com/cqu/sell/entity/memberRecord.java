package com.cqu.sell.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.*;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@TableName("member_record")
public class memberRecord {
    @TableId(value="id",type=IdType.AUTO)
    private Integer id;

    @TableField(value="record_id")
    private String recordId;

    @TableField(value="user_id")
    private Integer userId;

    private String type;

    @TableField(value="`change`")
    private Integer change;
    private Integer balance;
    private String reason;

    @TableField(value="order_id")
    private Integer orderId;
    private String time;
}