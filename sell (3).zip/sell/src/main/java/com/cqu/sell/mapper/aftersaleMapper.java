package com.cqu.sell.mapper;

import com.cqu.sell.entity.aftersale;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface aftersaleMapper extends BaseMapper<aftersale> {
}