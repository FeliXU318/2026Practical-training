package com.cqu.sell.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.cqu.sell.entity.run;
import com.cqu.sell.entity.order;
import com.cqu.sell.mapper.runMapper;
import com.cqu.sell.mapper.orderMapper;
import com.cqu.sell.service.runService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class runServiceImpl extends ServiceImpl<runMapper, run> implements runService {

    private final orderMapper orderMapper;

    public runServiceImpl(orderMapper orderMapper) {
        this.orderMapper = orderMapper;
    }

    @Override
    public List<run> getPendingTasks() {
        QueryWrapper<run> wrapper = new QueryWrapper<>();
        wrapper.eq("status_class", "status-pending");
        return baseMapper.selectList(wrapper);
    }

    @Override
    public run getTaskById(Integer id) {
        return baseMapper.selectById(id);
    }

    @Override
    public run publishTask(Integer userId, String type, String reward, String content, String location, String color) {
        run task = new run();
        task.setUserId(userId);
        task.setType(type);
        task.setReward(reward);
        task.setContent(content);
        task.setLocation(location);
        task.setColor(color);
        task.setStatus("待接取");
        task.setStatusClass("status-pending");
        task.setTime(java.time.LocalDateTime.now().format(java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));
        this.save(task);
        return task;
    }

    @Override
    public boolean acceptTask(Integer userId, Integer id) {
        run task = baseMapper.selectById(id);
        if (task != null && "status-pending".equals(task.getStatusClass())) {
            task.setRunnerId(userId);
            task.setStatus("进行中");
            task.setStatusClass("status-doing");
            this.updateById(task);

            order order = new order();
            order.setUserId(userId);
            order.setOrderType("跑腿");
            order.setTitle(task.getType());
            order.setContent(task.getContent());
            order.setReward(Double.parseDouble(task.getReward()));
            order.setOrderStatus("进行中");
            order.setStatusClass("status-doing");
            order.setTime(task.getTime());
            order.setLocation(task.getLocation());
            order.setColor(task.getColor());
            order.setRewarded(false);
            
            orderMapper.insert(order);
            
            return true;
        }
        return false;
    }

    @Override
    public boolean completeTask(Integer id, String deliveryPhoto, String deliveryDesc) {
        run task = baseMapper.selectById(id);
        if (task != null && "status-doing".equals(task.getStatusClass())) {
            task.setDeliveryPhoto(deliveryPhoto);
            task.setDeliveryDesc(deliveryDesc);
            task.setStatus("已完成");
            task.setStatusClass("status-done");
            return this.updateById(task);
        }
        return false;
    }
}