package com.cqu.sell.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.*;
import lombok.Getter;
import lombok.Setter;
import java.util.Date;

@Getter
@Setter
@TableName("user")
public class user {

    @TableId(value="user_id",type = IdType.AUTO)
    private Integer userId;

    private String phone;
    private String nickname;
    private String password;
    private String avatar;
    private String city;
    private String status;
    private Date created_at;

}
