package com.cqu.sell.controller;

import com.cqu.sell.entity.product;
import com.cqu.sell.entity.merchant;
import com.cqu.sell.service.productService;
import com.cqu.sell.mapper.merchantMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.HashSet;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;

@RestController
@RequestMapping("/api/product")
public class productController {

    @Autowired
    private productService productService;

    @Autowired
    private merchantMapper merchantMapper;

    @GetMapping("/supermarket")
    public Map<String,Object> getSupermarketProducts(@RequestParam Integer merchantId, @RequestParam(required = false) String keyword){
        Map<String,Object> result = new HashMap<>();
        
        QueryWrapper<product> wrapper = new QueryWrapper<>();
        wrapper.eq("merchant_id", merchantId);

        if (keyword != null && !keyword.isEmpty()) {
            wrapper.like("product_name", keyword);
        }
        
        List<product> products = productService.list(wrapper);
        
        List<Map<String, Object>> list = new ArrayList<>();
        for (product p : products) {
            Map<String, Object> item = new HashMap<>();
            item.put("id", p.getProductId());
            item.put("name", p.getProductName());
            item.put("price", p.getPrice());
            item.put("originalPrice", p.getOriginalPrice());
            item.put("sales", p.getSales());
            item.put("stock", p.getStock() != null ? p.getStock() : 0);
            item.put("categoryId", p.getCategoryId());
            item.put("image", p.getImage());
            list.add(item);
        }
        
        List<Map<String, Object>> categories = new ArrayList<>();
        categories.add(Map.of("id", 1, "name", "零食", "icon", "🍪"));
        categories.add(Map.of("id", 2, "name", "饮料", "icon", "🥤"));
        categories.add(Map.of("id", 3, "name", "日用", "icon", "🧴"));
        categories.add(Map.of("id", 4, "name", "文具", "icon", "📝"));
        
        result.put("success", true);
        result.put("list", list);
        result.put("categories", categories);
        return result;
    }

    @GetMapping("/fruit")
    public Map<String,Object> getFruitProducts(@RequestParam Integer merchantId, @RequestParam(required = false) String keyword){
        Map<String,Object> result = new HashMap<>();
        
        QueryWrapper<product> wrapper = new QueryWrapper<>();

        wrapper.eq("merchant_id", merchantId);

        if (keyword != null && !keyword.isEmpty()) {
            wrapper.like("product_name", keyword);
        }
        
        List<product> products = productService.list(wrapper);
        
        List<Map<String, Object>> list = new ArrayList<>();
        for (product p : products) {
            Map<String, Object> item = new HashMap<>();
            item.put("id", p.getProductId());
            item.put("name", p.getProductName());
            item.put("price", p.getPrice());
            item.put("unit", p.getUnit());
            item.put("sales", p.getSales());
            item.put("stock", p.getStock() != null ? p.getStock() : 0);
            item.put("categoryId", p.getCategoryId());
            item.put("image", p.getImage());
            item.put("tag", p.getTag());
            list.add(item);
        }
        
        List<Map<String, Object>> categories = new ArrayList<>();
        categories.add(Map.of("id", 1, "name", "苹果", "icon", "🍎"));
        categories.add(Map.of("id", 2, "name", "香蕉", "icon", "🍌"));
        categories.add(Map.of("id", 3, "name", "橙子", "icon", "🍊"));
        categories.add(Map.of("id", 4, "name", "葡萄", "icon", "🍇"));
        
        result.put("success", true);
        result.put("list", list);
        result.put("categories", categories);
        return result;
    }

    private Set<Integer> getActiveMerchantIds() {
        Set<Integer> ids = new HashSet<>();
        QueryWrapper<merchant> wrapper = new QueryWrapper<>();
        wrapper.eq("status", "营业中");
        List<merchant> merchants = merchantMapper.selectList(wrapper);
        for (merchant m : merchants) {
            ids.add(m.getMerchantId());
        }
        return ids;
    }
}