package com.cqu.sell.service;

import com.cqu.sell.entity.simcard;
import com.baomidou.mybatisplus.extension.service.IService;
import java.util.List;

public interface simcardService extends IService<simcard> {
    List<simcard> getPlans();
    Integer apply(Integer userId, Integer planId, String name, String phone, String idCard, String address);
}