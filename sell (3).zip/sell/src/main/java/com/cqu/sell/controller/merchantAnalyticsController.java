package com.cqu.sell.controller;

import com.cqu.sell.entity.order;
import com.cqu.sell.entity.product;
import com.cqu.sell.mapper.orderMapper;
import com.cqu.sell.mapper.productMapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/merchant/analytics")
public class merchantAnalyticsController {

    @Autowired
    private orderMapper orderMapper;

    @Autowired
    private productMapper productMapper;

    @GetMapping
    public Map<String, Object> analytics(@RequestParam String businessType, 
                                         @RequestParam(required = false) String period) {
        Map<String, Object> result = new HashMap<>();
        
        List<Map<String, Object>> summary = new ArrayList<>();
        Map<String, Object> salesItem = new HashMap<>();
        salesItem.put("label", "销售额");
        salesItem.put("value", "¥328.0");
        salesItem.put("delta", "+12.8%");
        summary.add(salesItem);
        
        Map<String, Object> orderItem = new HashMap<>();
        orderItem.put("label", "订单数");
        orderItem.put("value", 12);
        orderItem.put("delta", "+6 单");
        summary.add(orderItem);
        
        List<Map<String, Object>> trend = new ArrayList<>();
        String[] days = {"周一", "周二", "周三", "周四", "周五", "周六", "周日"};
        for (String day : days) {
            Map<String, Object> dayItem = new HashMap<>();
            dayItem.put("label", day);
            dayItem.put("value", (int) (Math.random() * 50 + 30));
            dayItem.put("amount", (int) (Math.random() * 500 + 200));
            trend.add(dayItem);
        }
        
        QueryWrapper<product> productWrapper = new QueryWrapper<>();
        if ("fruit".equals(businessType) || businessType.contains("fruit")) {
            productWrapper.eq("product_type", "fruit");
        } else {
            productWrapper.eq("product_type", "supermarket");
        }
        List<product> products = productMapper.selectList(productWrapper);
        
        List<Map<String, Object>> topProducts = new ArrayList<>();
        for (int i = 0; i < Math.min(5, products.size()); i++) {
            product p = products.get(i);
            Map<String, Object> item = new HashMap<>();
            item.put("id", p.getProductId());
            item.put("rank", i + 1);
            item.put("name", p.getProductName());
            item.put("sales", p.getSales() != null ? p.getSales() : 0);
            item.put("percent", (i == 0) ? 100 : (int) (Math.random() * 60 + 40));
            topProducts.add(item);
        }
        
        List<Map<String, Object>> inventory = new ArrayList<>();
        for (product p : products) {
            Map<String, Object> item = new HashMap<>();
            item.put("name", p.getProductName());
            item.put("stock", 999);
            item.put("status", "可售");
            inventory.add(item);
        }
        
        Map<String, Object> data = new HashMap<>();
        data.put("summary", summary);
        data.put("trend", trend);
        data.put("topProducts", topProducts);
        data.put("inventory", inventory);
        
        result.put("code", 0);
        result.put("message", "ok");
        result.put("data", data);
        return result;
    }
}