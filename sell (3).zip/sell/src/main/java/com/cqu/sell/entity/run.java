package com.cqu.sell.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.*;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@TableName("run")
public class run {
    @TableId(value="id",type=IdType.AUTO)
    private Integer id;

    @TableField(value="user_id")
    private Integer userId;

    @TableField(value="runner_id")
    private Integer runnerId;

    private String type;
    private String reward;
    private String content;
    private String user;
    private String avatar;
    private String location;
    private String time;
    private String status;

    @TableField(value="status_class")
    private String statusClass;
    private String color;

    @TableField(value="delivery_photo")
    private String deliveryPhoto;

    @TableField(value="delivery_desc")
    private String deliveryDesc;
}