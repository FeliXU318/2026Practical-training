package com.cqu.sell.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.cqu.sell.service.chatService;
import java.util.HashMap;
import java.util.Map;
import java.util.List;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/chat")
public class chatController {

    @Autowired
    private chatService chatService;

    private Integer getUserIdFromToken(String token) {
        if (token != null && token.startsWith("Bearer token_")) {
            try {
                return Integer.parseInt(token.substring(13));
            } catch (Exception e) {
                return null;
            }
        }
        return null;
    }

    @GetMapping("/sessions")
    public Map<String, Object> getSessions(@RequestHeader(value = "Authorization", required = false) String token) {
        Map<String, Object> result = new HashMap<>();
        Integer userId = getUserIdFromToken(token);
        
        if (userId == null) {
            result.put("code", 1);
            result.put("message", "未登录");
            return result;
        }
        
        List<Map<String, Object>> sessions = chatService.getSessions(userId);
        result.put("code", 0);
        result.put("message", "ok");
        result.put("data", sessions);
        return result;
    }

    @PostMapping("/session")
    public Map<String, Object> createOrGetSession(@RequestHeader(value = "Authorization", required = false) String token,
                                                  @RequestBody Map<String, Object> body) {
        Map<String, Object> result = new HashMap<>();
        Integer userId = getUserIdFromToken(token);
        
        if (userId == null) {
            result.put("code", 1);
            result.put("message", "未登录");
            return result;
        }
        
        Object targetIdObj = body.get("targetId");
        Integer targetId = targetIdObj != null ? ((Number) targetIdObj).intValue() : null;
        
        if (targetId == null) {
            result.put("code", 1);
            result.put("message", "缺少目标用户ID");
            return result;
        }
        
        Map<String, Object> session = chatService.createOrGetSession(userId, targetId);
        result.put("code", 0);
        result.put("message", "ok");
        result.put("data", session);
        return result;
    }

    @DeleteMapping("/session")
    public Map<String, Object> deleteSession(@RequestHeader(value = "Authorization", required = false) String token,
                                             @RequestBody Map<String, Object> body) {
        Map<String, Object> result = new HashMap<>();
        Integer userId = getUserIdFromToken(token);
        
        if (userId == null) {
            result.put("code", 1);
            result.put("message", "未登录");
            return result;
        }
        
        String sessionKey = (String) body.get("session_key");
        if (sessionKey == null || sessionKey.isEmpty()) {
            result.put("code", 1);
            result.put("message", "缺少会话ID");
            return result;
        }
        
        boolean success = chatService.deleteSession(userId, sessionKey);
        result.put("code", success ? 0 : 1);
        result.put("message", success ? "删除成功" : "删除失败");
        return result;
    }

    @PostMapping("/read")
    public Map<String, Object> markRead(@RequestHeader(value = "Authorization", required = false) String token,
                                        @RequestBody Map<String, Object> body) {
        Map<String, Object> result = new HashMap<>();
        Integer userId = getUserIdFromToken(token);
        
        if (userId == null) {
            result.put("code", 1);
            result.put("message", "未登录");
            return result;
        }
        
        String sessionKey = (String) body.get("session_key");
        if (sessionKey == null || sessionKey.isEmpty()) {
            result.put("code", 1);
            result.put("message", "缺少会话ID");
            return result;
        }
        
        boolean success = chatService.markRead(userId, sessionKey);
        result.put("code", success ? 0 : 1);
        result.put("message", success ? "已标记为已读" : "标记失败");
        return result;
    }

    @GetMapping("/messages")
    public Map<String, Object> getMessages(@RequestHeader(value = "Authorization", required = false) String token,
                                           @RequestParam String session_key,
                                           @RequestParam(defaultValue = "1") Integer page,
                                           @RequestParam(defaultValue = "20") Integer size) {
        Map<String, Object> result = new HashMap<>();
        Integer userId = getUserIdFromToken(token);
        
        if (userId == null) {
            result.put("code", 1);
            result.put("message", "未登录");
            return result;
        }
        
        List<Map<String, Object>> messages = chatService.getMessages(session_key, page, size);
        result.put("code", 0);
        result.put("message", "ok");
        result.put("data", messages);
        result.put("hasMore", messages.size() >= size);
        return result;
    }

    @PostMapping("/send")
    public Map<String, Object> sendMessage(@RequestHeader(value = "Authorization", required = false) String token,
                                           @RequestBody Map<String, Object> body) {
        Map<String, Object> result = new HashMap<>();
        Integer userId = getUserIdFromToken(token);
        
        if (userId == null) {
            result.put("code", 1);
            result.put("message", "未登录");
            return result;
        }
        
        String sessionKey = (String) body.get("session_key");
        Object receiverIdObj = body.get("receiverId");
        String content = (String) body.get("content");
        String type = (String) body.get("type");
        
        if (sessionKey == null || sessionKey.isEmpty()) {
            result.put("code", 1);
            result.put("message", "缺少会话ID");
            return result;
        }
        
        Integer receiverId = receiverIdObj != null ? ((Number) receiverIdObj).intValue() : null;
        if (receiverId == null) {
            result.put("code", 1);
            result.put("message", "缺少接收者ID");
            return result;
        }
        
        if (content == null || content.isEmpty()) {
            result.put("code", 1);
            result.put("message", "消息内容不能为空");
            return result;
        }
        
        Map<String, Object> message = chatService.sendMessage(userId, sessionKey, receiverId, content, type);
        result.put("code", 0);
        result.put("message", "ok");
        result.put("data", message);
        return result;
    }

    @GetMapping("/search")
    public Map<String, Object> searchUser(@RequestHeader(value = "Authorization", required = false) String token,
                                          @RequestParam String keyword) {
        Map<String, Object> result = new HashMap<>();
        Integer userId = getUserIdFromToken(token);
        
        if (userId == null) {
            result.put("code", 1);
            result.put("message", "未登录");
            return result;
        }
        
        List<Map<String, Object>> users = chatService.searchUser(keyword);
        result.put("code", 0);
        result.put("message", "ok");
        result.put("data", users);
        return result;
    }

}