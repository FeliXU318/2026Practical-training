package com.cqu.sell.controller;

import com.cqu.sell.entity.order;
import com.cqu.sell.mapper.orderMapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/merchant/delivery")
public class merchantDeliveryController {

    @Autowired
    private orderMapper orderMapper;

    @GetMapping("/tasks")
    public Map<String, Object> list(@RequestParam String businessType, 
                                    @RequestParam(required = false) String status) {
        Map<String, Object> result = new HashMap<>();
        
        QueryWrapper<order> wrapper = new QueryWrapper<>();
        wrapper.eq("status_class", "status-delivering");
        
        List<order> orders = orderMapper.selectList(wrapper);
        
        List<Map<String, Object>> list = new ArrayList<>();
        for (order o : orders) {
            Map<String, Object> item = new HashMap<>();
            item.put("id", "D" + o.getOrderId());
            item.put("orderId", o.getOrderId());
            item.put("businessType", businessType);
            item.put("orderNo", "O" + String.format("%010d", o.getOrderId()));
            item.put("dorm", "");
            item.put("reserveTime", "今天");
            item.put("riderName", "");
            item.put("status", "delivering");
            item.put("itemSummary", o.getTitle());
            list.add(item);
        }
        
        result.put("code", 0);
        result.put("message", "ok");
        result.put("data", list);
        return result;
    }

    @PostMapping("/assign")
    public Map<String, Object> assign(@RequestBody Map<String, Object> body) {
        Map<String, Object> result = new HashMap<>();
        String id = (String) body.get("id");
        String riderName = (String) body.get("riderName");
        
        Integer orderId = Integer.parseInt(id.substring(1));
        order o = orderMapper.selectById(orderId);
        
        if (o != null) {
            Map<String, Object> data = new HashMap<>();
            data.put("id", id);
            data.put("orderId", orderId);
            data.put("riderName", riderName);
            data.put("status", "assigned");
            
            result.put("code", 0);
            result.put("message", "ok");
            result.put("data", data);
        } else {
            result.put("code", 1);
            result.put("message", "任务不存在");
        }
        
        return result;
    }

    @PostMapping("/complete")
    public Map<String, Object> complete(@RequestBody Map<String, Object> body) {
        Map<String, Object> result = new HashMap<>();
        String id = (String) body.get("id");
        
        Integer orderId = Integer.parseInt(id.substring(1));
        order o = orderMapper.selectById(orderId);
        
        if (o != null) {
            o.setOrderStatus("已完成");
            o.setStatusClass("status-done");
            orderMapper.updateById(o);
            
            Map<String, Object> data = new HashMap<>();
            data.put("id", id);
            data.put("orderId", orderId);
            data.put("status", "done");
            
            result.put("code", 0);
            result.put("message", "ok");
            result.put("data", data);
        } else {
            result.put("code", 1);
            result.put("message", "任务不存在");
        }
        
        return result;
    }
}