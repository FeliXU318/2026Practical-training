package com.cqu.sell.controller;

import com.cqu.sell.entity.product;
import com.cqu.sell.mapper.productMapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.io.File;

@RestController
@RequestMapping("/api/merchant/products")
public class merchantProductsController {

    @Autowired
    private productMapper productMapper;

    @GetMapping
    public Map<String, Object> list(@RequestParam String businessType, 
                                    @RequestParam Integer merchantId,
                                    @RequestParam(required = false) String keyword, 
                                    @RequestParam(required = false) String status) {
        Map<String, Object> result = new HashMap<>();
        QueryWrapper<product> wrapper = new QueryWrapper<>();

        wrapper.eq("merchant_id", merchantId);
        
        if (keyword != null && !keyword.isEmpty()) {
            wrapper.like("product_name", keyword).or().like("category", keyword);
        }
        
        if ("on".equals(status)) {
            wrapper.eq("tag", "on");
        } else if ("off".equals(status)) {
            wrapper.eq("tag", "off");
        }
        
        List<product> goodsList = productMapper.selectList(wrapper);
        
        if (goodsList.isEmpty()) {
            wrapper.clear();
            wrapper.eq("merchant_id", merchantId);
            if (keyword != null && !keyword.isEmpty()) {
                wrapper.like("product_name", keyword).or().like("category", keyword);
            }
            if ("on".equals(status)) {
                wrapper.eq("tag", "on");
            } else if ("off".equals(status)) {
                wrapper.eq("tag", "off");
            }
            goodsList = productMapper.selectList(wrapper);
        }
        
        List<Map<String, Object>> list = new ArrayList<>();
        for (product goods : goodsList) {
            Map<String, Object> item = new HashMap<>();
            item.put("id", goods.getProductId());
            item.put("businessType", businessType);
            item.put("name", goods.getProductName());
            item.put("category", goods.getCategory());
            item.put("price", goods.getPrice());
            Integer stock = goods.getStock() != null ? goods.getStock() : 0;
            item.put("stock", stock);
            item.put("sales", goods.getSales() != null ? goods.getSales() : 0);
            item.put("onSale", "on".equals(goods.getTag()) && stock > 0);
            item.put("imageUrl", goods.getImage());
            item.put("imageTone", "tone-orange");
            item.put("shortName", goods.getProductName() != null && goods.getProductName().length() > 0 ? 
                                goods.getProductName().substring(0, 1) : "");
            item.put("statusText", stock <= 0 ? "售罄" : ("on".equals(goods.getTag()) ? "已上架" : "已下架"));
            item.put("statusClass", stock <= 0 ? "status-off" : ("on".equals(goods.getTag()) ? "status-on" : "status-off"));
            item.put("stockStatus", stock <= 0 ? "售罄" : (stock < 10 ? "需补货" : "库存正常"));
            item.put("tags", new ArrayList<>());
            item.put("description", "");
            item.put("isDaily", false);
            list.add(item);
        }
        
        result.put("code", 0);
        result.put("message", "ok");
        result.put("data", list);
        return result;
    }

    @GetMapping("/{id}")
    public Map<String, Object> detail(@PathVariable Integer id) {
        Map<String, Object> result = new HashMap<>();
        product goods = productMapper.selectById(id);
        
        if (goods != null) {
            Map<String, Object> data = new HashMap<>();
            data.put("id", goods.getProductId());
            data.put("businessType", "");
            data.put("name", goods.getProductName());
            data.put("category", goods.getCategory());
            data.put("price", goods.getPrice());
            Integer stock = goods.getStock() != null ? goods.getStock() : 0;
            data.put("stock", stock);
            data.put("sales", goods.getSales() != null ? goods.getSales() : 0);
            data.put("onSale", "on".equals(goods.getTag()) && stock > 0);
            data.put("imageUrl", goods.getImage());
            data.put("imageTone", "tone-orange");
            data.put("shortName", goods.getProductName() != null && goods.getProductName().length() > 0 ? 
                                goods.getProductName().substring(0, 1) : "");
            data.put("statusText", stock <= 0 ? "售罄" : ("on".equals(goods.getTag()) ? "已上架" : "已下架"));
            data.put("statusClass", stock <= 0 ? "status-off" : ("on".equals(goods.getTag()) ? "status-on" : "status-off"));
            data.put("stockStatus", stock <= 0 ? "售罄" : (stock < 10 ? "需补货" : "库存正常"));
            data.put("tags", new ArrayList<>());
            data.put("description", "");
            data.put("isDaily", false);
            
            result.put("code", 0);
            result.put("message", "ok");
            result.put("data", data);
        } else {
            result.put("code", 1);
            result.put("message", "商品不存在");
        }
        
        return result;
    }

    @PostMapping
    public Map<String, Object> create(@RequestBody Map<String, Object> body) {
        Map<String, Object> result = new HashMap<>();
        
        product goods = new product();
        goods.setProductName((String) body.get("name"));
        goods.setCategory((String) body.get("category"));
        goods.setPrice(toFloat(body.get("price")));
        goods.setSales(0);
        Object stockObj = body.get("stock");
        goods.setStock(stockObj != null ? toInt(stockObj) : 0);
        goods.setImage((String) body.get("imageUrl"));
        goods.setTag(body.get("onSale") != null && ((Boolean) body.get("onSale")) ? "on" : "off");
        
        Object merchantIdObj = body.get("merchantId");
        if (merchantIdObj == null) {
            merchantIdObj = body.get("merchant_id");
        }
        if (merchantIdObj != null) {
            goods.setMerchantId(toInt(merchantIdObj));
        }
        
        String merchantCategory = (String) body.get("merchantCategory");
        if ("fruit".equals(merchantCategory)) {
            goods.setProductType("fruit");
        } else {
            goods.setProductType("supermarket");
        }
        
        productMapper.insert(goods);
        
        Map<String, Object> data = new HashMap<>();
        data.put("id", goods.getProductId());
        data.put("name", goods.getProductName());
        data.put("category", goods.getCategory());
        data.put("price", goods.getPrice());
        
        result.put("code", 0);
        result.put("message", "ok");
        result.put("data", data);
        return result;
    }

    @PutMapping
    public Map<String, Object> update(@RequestBody Map<String, Object> body) {
        Map<String, Object> result = new HashMap<>();
        
        Integer id = toInt(body.get("id"));
        product goods = productMapper.selectById(id);
        
        if (goods != null) {
            goods.setProductName((String) body.get("name"));
            goods.setCategory((String) body.get("category"));
            goods.setPrice(toFloat(body.get("price")));
            Object stockObj = body.get("stock");
            if (stockObj != null) {
                goods.setStock(toInt(stockObj));
            }
            goods.setImage((String) body.get("imageUrl"));
            goods.setTag(body.get("onSale") != null && ((Boolean) body.get("onSale")) ? "on" : "off");
            
            Object merchantIdObj = body.get("merchantId");
            if (merchantIdObj == null) {
                merchantIdObj = body.get("merchant_id");
            }
            if (merchantIdObj != null) {
                goods.setMerchantId(toInt(merchantIdObj));
            }
            
            String merchantCategory = (String) body.get("merchantCategory");
            if (merchantCategory != null) {
                if ("fruit".equals(merchantCategory)) {
                    goods.setProductType("fruit");
                } else {
                    goods.setProductType("supermarket");
                }
            }
            
            productMapper.updateById(goods);
            
            Map<String, Object> data = new HashMap<>();
            data.put("id", goods.getProductId());
            data.put("name", goods.getProductName());
            data.put("category", goods.getCategory());
            data.put("price", goods.getPrice());
            
            result.put("code", 0);
            result.put("message", "ok");
            result.put("data", data);
        } else {
            result.put("code", 1);
            result.put("message", "商品不存在");
        }
        
        return result;
    }

    @PatchMapping("/stock")
    public Map<String, Object> updateStock(@RequestBody Map<String, Object> body) {
        Map<String, Object> result = new HashMap<>();
        Integer id = toInt(body.get("id"));
        Integer delta = toInt(body.get("delta"));
        product goods = productMapper.selectById(id);
        
        if (goods != null) {
            Integer currentStock = goods.getStock() != null ? goods.getStock() : 0;
            Integer newStock = currentStock + delta;
            if (newStock < 0) {
                newStock = 0;
            }
            goods.setStock(newStock);
            productMapper.updateById(goods);
            
            Map<String, Object> data = new HashMap<>();
            data.put("id", goods.getProductId());
            data.put("stock", goods.getStock());
            data.put("name", goods.getProductName());
            
            result.put("code", 0);
            result.put("message", "ok");
            result.put("data", data);
        } else {
            result.put("code", 1);
            result.put("message", "商品不存在");
        }
        
        return result;
    }

    @PatchMapping("/status")
    public Map<String, Object> toggleStatus(@RequestBody Map<String, Object> body) {
        Map<String, Object> result = new HashMap<>();
        Integer id = ((Number) body.get("id")).intValue();
        product goods = productMapper.selectById(id);
        
        if (goods != null) {
            goods.setTag("on".equals(goods.getTag()) ? "off" : "on");
            productMapper.updateById(goods);
            
            Map<String, Object> data = new HashMap<>();
            data.put("id", goods.getProductId());
            data.put("onSale", "on".equals(goods.getTag()));
            data.put("statusText", "on".equals(goods.getTag()) ? "已上架" : "已下架");
            data.put("statusClass", "on".equals(goods.getTag()) ? "status-on" : "status-off");
            
            result.put("code", 0);
            result.put("message", "ok");
            result.put("data", data);
        } else {
            result.put("code", 1);
            result.put("message", "商品不存在");
        }
        
        return result;
    }

    @PostMapping("/photo")
    public Map<String, Object> uploadPhoto(@RequestParam("file") MultipartFile file, 
                                           @RequestParam(required = false) String type) {
        Map<String, Object> result = new HashMap<>();
        try {
            String uploadDir = "D:/uploads";
            String accessUrl = "http://10.120.113.18:8080/images";
            
            String originalName = file.getOriginalFilename();
            String ext = "";
            if (originalName != null && originalName.contains(".")) {
                ext = originalName.substring(originalName.lastIndexOf("."));
            }
            String fileName = UUID.randomUUID().toString().replace("-", "") + ext;
            
            File dest = new File(uploadDir, fileName);
            if (!dest.getParentFile().exists()) {
                dest.getParentFile().mkdirs();
            }
            file.transferTo(dest);
            
            String url = accessUrl + "/" + fileName;
            result.put("code", 0);
            result.put("message", "ok");
            
            Map<String, Object> data = new HashMap<>();
            data.put("imageUrl", url);
            data.put("url", url);
            result.put("data", data);
        } catch (Exception e) {
            result.put("code", 1);
            result.put("message", "上传失败");
        }
        return result;
    }

    private float toFloat(Object value) {
        if (value == null) {
            return 0f;
        }
        if (value instanceof Number) {
            return ((Number) value).floatValue();
        }
        return Float.parseFloat(value.toString());
    }

    private int toInt(Object value) {
        if (value == null) {
            return 0;
        }
        if (value instanceof Number) {
            return ((Number) value).intValue();
        }
        return Integer.parseInt(value.toString());
    }

    private String determineProductType(String businessType) {
        if (businessType != null) {
            if (businessType.contains("fruit") || businessType.contains("FRUIT")) {
                return "fruit";
            }
        }
        return "supermarket";
    }
}