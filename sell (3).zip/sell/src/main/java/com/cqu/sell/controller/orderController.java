package com.cqu.sell.controller;

import com.cqu.sell.entity.order;
import com.cqu.sell.entity.product;
import com.cqu.sell.entity.merchant;
import com.cqu.sell.service.orderService;
import com.cqu.sell.service.memberService;
import com.cqu.sell.mapper.productMapper;
import com.cqu.sell.mapper.merchantMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;

@RestController
@RequestMapping("/api/order")
public class orderController {

    @Autowired
    private orderService orderService;
    
    @Autowired
    private memberService memberService;
    
    @Autowired
    private productMapper productMapper;
    
    @Autowired
    private merchantMapper merchantMapper;

    @GetMapping("/list")
    public Map<String,Object> list(@RequestHeader(value = "Authorization") String token,
                                   @RequestParam(required = false) String statusClass,
                                   @RequestParam(required = false) String orderType,
                                   @RequestParam(defaultValue = "1") Integer page,
                                   @RequestParam(defaultValue = "20") Integer pageSize){
        Map<String,Object> result = new HashMap<>();
        
        Integer userId = Integer.parseInt(token.substring(7).replace("token_", ""));
        
        QueryWrapper<order> wrapper = new QueryWrapper<>();
        wrapper.eq("user_id", userId);
        if (statusClass != null && !statusClass.isEmpty()) {
            wrapper.eq("status_class", statusClass);
        }
        if (orderType != null && !orderType.isEmpty()) {
            wrapper.eq("order_type", orderType);
        }
        wrapper.orderByDesc("time");
        
        List<order> orders = orderService.list(wrapper);
        
        int total = orders.size();
        int start = (page - 1) * pageSize;
        int end = Math.min(start + pageSize, total);
        
        List<Map<String, Object>> list = new ArrayList<>();
        for (int i = start; i < end; i++) {
            order o = orders.get(i);
            Map<String, Object> item = new HashMap<>();
            item.put("id", o.getOrderId());
            item.put("orderType", o.getOrderType());
            item.put("title", o.getTitle());
            item.put("content", o.getContent());
            item.put("reward", o.getReward());
            item.put("status", o.getOrderStatus());
            item.put("statusClass", o.getStatusClass());
            item.put("time", o.getTime());
            item.put("location", o.getLocation());
            item.put("color", o.getColor());
            item.put("rewarded", o.getRewarded());
            item.put("afterSaleId", o.getAfterSaleId());
            list.add(item);
        }
        
        result.put("success", true);
        result.put("list", list);
        result.put("total", total);
        return result;
    }

    @GetMapping("/detail")
    public Map<String,Object> detail(@RequestHeader(value = "Authorization") String token, @RequestParam Integer id){
        Map<String,Object> result = new HashMap<>();
        
        order order = orderService.getOrderById(id);
        if (order != null) {
            result.put("success", true);
            result.put("id", order.getOrderId());
            result.put("orderType", order.getOrderType());
            result.put("title", order.getTitle());
            result.put("content", order.getContent());
            result.put("reward", order.getReward());
            result.put("status", order.getOrderStatus());
            result.put("statusClass", order.getStatusClass());
            result.put("time", order.getTime());
            result.put("location", order.getLocation());
            result.put("color", order.getColor());
            result.put("rewarded", order.getRewarded());
        } else {
            result.put("success", false);
            result.put("message", "订单不存在");
        }
        
        return result;
    }

    @PostMapping("/create")
    public Map<String,Object> create(@RequestHeader(value = "Authorization") String token, @RequestBody Map<String, Object> body){
        Map<String,Object> result = new HashMap<>();
        
        Integer userId = Integer.parseInt(token.substring(7).replace("token_", ""));
        
        String orderType = (String) body.get("orderType");
        String content = (String) body.get("content");
        Object merchantIdObj = body.get("merchantId");
        String address = (String) body.get("address");
        String phone = (String) body.get("phonenum");
        String delivertype = (String) body.get("deliver_type");
        if (merchantIdObj == null) {
            merchantIdObj = body.get("merchant_id");
        }
        Integer merchantId = merchantIdObj != null ? toInt(merchantIdObj) : null;
        
        if (content != null && !content.isEmpty() && merchantId != null) {
            List<Map<String, Object>> items = parseOrderContent(content);
            for (Map<String, Object> item : items) {
                String productName = (String) item.get("name");
                Integer quantity = (Integer) item.get("quantity");
                
                QueryWrapper<product> wrapper = new QueryWrapper<>();
                wrapper.eq("product_name", productName);
                wrapper.eq("merchant_id", merchantId);
                product p = productMapper.selectOne(wrapper);
                if (p != null) {
                    Integer stock = p.getStock() != null ? p.getStock() : 0;
                    if (stock < quantity) {
                        result.put("success", false);
                        result.put("message", p.getProductName() + "库存不足，当前库存：" + stock);
                        return result;
                    }
                }
            }
        }
        
        order order = new order();
        order.setUserId(userId);
        order.setMerchantId(merchantId);
        order.setOrderType(orderType);
        order.setTitle((String) body.get("title"));
        order.setContent(content);
        order.setAddress(address);
        order.setPhone(phone);
        order.setDeliverType(delivertype);
        
        Object rewardObj = body.get("reward");
        if (rewardObj != null) {
            order.setReward(Double.parseDouble(rewardObj.toString()));
            order.setTotalAmount(Double.parseDouble(rewardObj.toString()));
        } else {
            order.setReward(0.0);
            order.setTotalAmount(0.0);
        }
        order.setLocation((String) body.get("location"));
        order.setColor((String) body.get("color"));
        order.setOrderStatus("待支付");
        order.setStatusClass("status-pay");
        order.setTime(java.time.LocalDateTime.now().format(java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));
        order.setRewarded(false);
        
        orderService.save(order);
        
        Map<String, Object> orderMap = new HashMap<>();
        orderMap.put("id", order.getOrderId());
        orderMap.put("status", order.getOrderStatus());
        orderMap.put("statusClass", order.getStatusClass());
        orderMap.put("time", order.getTime());
        orderMap.put("rewarded", order.getRewarded());
        
        result.put("success", true);
        result.put("message", "下单成功");
        result.put("order", orderMap);
        return result;
    }

    @PostMapping("/pay")
    public Map<String,Object> pay(@RequestHeader(value = "Authorization") String token, @RequestBody Map<String, Integer> body){
        Map<String,Object> result = new HashMap<>();
        
        Integer id = body.get("id");
        order order = orderService.getOrderById(id);
        
        if (order != null && "status-pay".equals(order.getStatusClass())) {
            order.setOrderStatus("待发货");
            order.setStatusClass("status-ship");
            orderService.updateById(order);
            result.put("success", true);
            result.put("message", "支付成功");
        } else {
            result.put("success", false);
            result.put("message", "订单状态异常");
        }
        
        return result;
    }

    @PostMapping("/cancel")
    public Map<String,Object> cancel(@RequestHeader(value = "Authorization") String token, @RequestBody Map<String, Integer> body){
        Map<String,Object> result = new HashMap<>();
        
        Integer id = body.get("id");
        order order = orderService.getOrderById(id);
        
        if (order != null && "status-pay".equals(order.getStatusClass())) {
            order.setOrderStatus("已取消");
            order.setStatusClass("status-cancel");
            orderService.updateById(order);
            result.put("success", true);
            result.put("message", "已取消");
        } else {
            result.put("success", false);
            result.put("message", "无法取消该订单");
        }
        
        return result;
    }

    @PostMapping("/ship")
    public Map<String,Object> ship(@RequestHeader(value = "Authorization") String token, @RequestBody Map<String, Object> body){
        Map<String,Object> result = new HashMap<>();
        
        Integer id = (Integer) body.get("id");
        String shipType = (String) body.get("shipType");
        order order = orderService.getOrderById(id);
        
        if (order != null && "status-ship".equals(order.getStatusClass())) {
            if ("pickup".equals(shipType)) {
                order.setOrderStatus("待自提");
                order.setStatusClass("status-pickup");
            } else if ("delivery".equals(shipType)) {
                order.setOrderStatus("配送中");
                order.setStatusClass("status-delivering");
            }
            orderService.updateById(order);
            result.put("success", true);
            result.put("message", "已发货");
        } else {
            result.put("success", false);
            result.put("message", "订单状态异常");
        }
        
        return result;
    }

    @PostMapping("/verify")
    public Map<String,Object> verify(@RequestHeader(value = "Authorization") String token, @RequestBody Map<String, Object> body){
        Map<String,Object> result = new HashMap<>();
        
        Integer id = (Integer) body.get("id");
        String code = (String) body.get("code");
        order order = orderService.getOrderById(id);
        
        if (order != null && ("status-pickup".equals(order.getStatusClass()) || "status-ready".equals(order.getStatusClass()))) {
            String expectedCode = String.format("%06d", id % 1000000);
            if (expectedCode.equals(code)) {
                deductStock(order);
                order.setOrderStatus("已完成");
                order.setStatusClass("status-done");
                
                if (!order.getRewarded()) {
                    order.setRewarded(true);
                    if (!"二手".equals(order.getOrderType())) {
                        memberService.consume(order.getUserId(), order.getReward(), order.getOrderId());
                    }
                }
                
                orderService.updateById(order);
                result.put("success", true);
                result.put("message", "核销成功");
            } else {
                result.put("success", false);
                result.put("message", "取货码错误");
            }
        } else {
            result.put("success", false);
            result.put("message", "订单状态异常");
        }
        
        return result;
    }

    @PostMapping("/confirm")
    public Map<String,Object> confirm(@RequestHeader(value = "Authorization") String token, @RequestBody Map<String, Integer> body){
        Map<String,Object> result = new HashMap<>();
        
        Integer id = body.get("id");
        order order = orderService.getOrderById(id);
        
        if (order != null && ("status-delivering".equals(order.getStatusClass()) || "status-receive".equals(order.getStatusClass()))) {
            deductStock(order);
            order.setOrderStatus("已完成");
            order.setStatusClass("status-done");
            
            if (!order.getRewarded()) {
                order.setRewarded(true);
                if (!"二手".equals(order.getOrderType())) {
                    memberService.consume(order.getUserId(), order.getReward(), order.getOrderId());
                }
            }
            
            orderService.updateById(order);
            result.put("success", true);
            result.put("message", "已确认收货");
        } else {
            result.put("success", false);
            result.put("message", "订单状态异常");
        }
        
        return result;
    }

    public void deductStock(order order) {
        if ("status-done".equals(order.getStatusClass())) {
            return;
        }

        String content = order.getContent();
        if (content == null || content.isEmpty()) {
            return;
        }

        Integer merchantId = order.getMerchantId();

        List<Map<String, Object>> items = parseOrderContent(content);
        for (Map<String, Object> item : items) {
            String productName = (String) item.get("name");
            if (productName == null || productName.isEmpty()) {
                continue;
            }

            Integer quantity = (Integer) item.get("quantity");

            QueryWrapper<product> wrapper = new QueryWrapper<>();
            wrapper.eq("product_name", productName);
            if (merchantId != null) {
                wrapper.eq("merchant_id", merchantId);
            }
            product p = productMapper.selectOne(wrapper);

            if (p != null) {
                Integer stock = p.getStock() != null ? p.getStock() : 0;
                if (stock >= quantity) {
                    p.setStock(stock - quantity);
                    p.setSales((p.getSales() != null ? p.getSales() : 0) + quantity);
                    productMapper.updateById(p);
                }
            }
        }
    }

    @PostMapping("/remind")
    public Map<String,Object> remind(@RequestHeader(value = "Authorization") String token, @RequestBody Map<String, Integer> body){
        Map<String,Object> result = new HashMap<>();
        result.put("success", true);
        result.put("message", "已提醒商家");
        return result;
    }

    @GetMapping("/stats")
    public Map<String,Object> stats(@RequestHeader(value = "Authorization") String token){
        Map<String,Object> result = new HashMap<>();
        
        Integer userId = Integer.parseInt(token.substring(7).replace("token_", ""));
        
        QueryWrapper<order> wrapper = new QueryWrapper<>();
        wrapper.eq("user_id", userId);
        
        int pendingPay = (int) orderService.count(wrapper.clone().eq("status_class", "status-pay"));
        int pendingShip = (int) orderService.count(wrapper.clone().eq("status_class", "status-ship"));
        int pendingReceive = (int) orderService.count(wrapper.clone().in("status_class", List.of("status-pickup", "status-delivering", "status-receive")));
        int done = (int) orderService.count(wrapper.clone().eq("status_class", "status-done"));
        
        result.put("success", true);
        result.put("pendingPay", pendingPay);
        result.put("pendingShip", pendingShip);
        result.put("pendingReceive", pendingReceive);
        result.put("done", done);
        return result;
    }

    private Integer toInt(Object value) {
        if (value == null) {
            return 0;
        }
        if (value instanceof Number) {
            return ((Number) value).intValue();
        }
        return Integer.parseInt(value.toString());
    }

    private List<Map<String, Object>> parseOrderContent(String content) {
        List<Map<String, Object>> items = new ArrayList<>();
        if (content == null || content.isEmpty()) {
            return items;
        }
        Pattern pattern = Pattern.compile("([^×，,]+)×(\\d+)");
        Matcher matcher = pattern.matcher(content);
        while (matcher.find()) {
            String name = matcher.group(1).trim();
            Integer quantity = Integer.parseInt(matcher.group(2));
            Map<String, Object> item = new HashMap<>();
            item.put("name", name);
            item.put("quantity", quantity);
            items.add(item);
        }
        return items;
    }
}