package com.cqu.sell.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.cqu.sell.entity.cart;
import com.cqu.sell.mapper.cartMapper;
import com.cqu.sell.service.cartService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class cartServiceImpl extends ServiceImpl<cartMapper, cart> implements cartService {

    @Override
    public List<cart> getCartByUserAndKey(String userId, String cartKey) {
        QueryWrapper<cart> wrapper = new QueryWrapper<>();
        wrapper.eq("user_id", userId)
               .eq("cart_key", cartKey);
        return baseMapper.selectList(wrapper);
    }

    @Override
    public cart addToCart(String userId, String cartKey, Integer productId, String name, double price, String image) {
        QueryWrapper<cart> wrapper = new QueryWrapper<>();
        wrapper.eq("user_id", userId)
               .eq("cart_key", cartKey)
               .eq("product_id", productId);
        cart existing = baseMapper.selectOne(wrapper);
        
        if (existing != null) {
            existing.setQuantity(existing.getQuantity() + 1);
            this.updateById(existing);
            return existing;
        } else {
            cart newCart = new cart();
            newCart.setUserId(userId);
            newCart.setCartKey(cartKey);
            newCart.setProductId(productId);
            newCart.setName(name);
            newCart.setPrice(price);
            newCart.setImage(image);
            newCart.setQuantity(1);
            this.save(newCart);
            return newCart;
        }
    }

    @Override
    public cart updateQuantity(String userId, String cartKey, Integer productId, Integer quantity) {
        QueryWrapper<cart> wrapper = new QueryWrapper<>();
        wrapper.eq("user_id", userId)
               .eq("cart_key", cartKey)
               .eq("product_id", productId);
        cart cart = baseMapper.selectOne(wrapper);
        
        if (cart != null) {
            if (quantity <= 0) {
                this.removeById(cart.getId());
                return null;
            }
            cart.setQuantity(quantity);
            this.updateById(cart);
            return cart;
        }
        return null;
    }

    @Override
    public boolean clearCart(String userId, String cartKey) {
        QueryWrapper<cart> wrapper = new QueryWrapper<>();
        wrapper.eq("user_id", userId)
               .eq("cart_key", cartKey);
        return this.remove(wrapper);
    }
}