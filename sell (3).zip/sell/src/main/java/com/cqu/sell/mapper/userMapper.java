package com.cqu.sell.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.cqu.sell.entity.user;

public interface userMapper extends BaseMapper<user>{

}
