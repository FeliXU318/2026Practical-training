package com.cqu.sell.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.cqu.sell.entity.merchant;
import com.cqu.sell.mapper.merchantMapper;
import com.cqu.sell.service.merchantService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@Service
public class merchantServiceImpl extends ServiceImpl<merchantMapper,merchant> implements merchantService {


    @Override
    public List<merchant> findMerchantByType(String business_type){
        QueryWrapper<merchant> queryWrapper=new QueryWrapper<>();
        queryWrapper.eq("business_type",business_type);
        return baseMapper.selectList(queryWrapper);
    }

    @Override
    public List<merchant> findAll(){

        QueryWrapper<merchant> wrapper =new QueryWrapper<>();
        return baseMapper.selectList(wrapper);

    }

    @Override
    public List<merchant> findMerchantByName(String merchantName){
        QueryWrapper<merchant> wrapper =new QueryWrapper<>();
        wrapper.like("merchant_name",merchantName);
        return this.list(wrapper);

    }


    @Override
    public boolean addMerchant(merchant merchant){
       return this.save(merchant);
    }

    @Override
    public boolean deleteMerchant(int merchant_id){
        return this.removeById(merchant_id);
    }

    @Override
    public boolean updateMerchantName(int merchant_id,String merchant_name){
        merchant m = this.getById(merchant_id);
        String old_name = m.getMerchantName();
        if(!old_name.equals(merchant_name)){
            m.setMerchantName(merchant_name);
            this.updateById(m);
            return true;
        }
        else return false;
    }

    @Override
    public boolean updateContactPhone(int merchant_id,String phone){
        merchant m = this.getById(merchant_id);
        String old_phone = m.getContactPhone();
        if(!old_phone.equals(phone)){
            m.setContactPhone(phone);
            this.updateById(m);
            return true;
        }
        else return false;
    }

    @Override
    public IPage<merchant> getMerchantPage(long current, long size){
        Page<merchant> page=new Page<>(current,size);
        QueryWrapper<merchant> wrapper=new QueryWrapper<>();
        wrapper.orderByAsc("id");
        return this.page(page,wrapper);
    }

    public boolean updateStatus(int merchant_id, String status){
        merchant m = this.getById(merchant_id);
        String old_status = m.getStatus();
        if(!old_status.equals(status)){
            m.setStatus(status);
            this.updateById(m);
            return true;
        }
        else return false;
    }

    @Override
    public Map<String, Object> login(String account, String password, String dormBuilding, String merchantCategory) {
        Map<String, Object> result = new HashMap<>();
        QueryWrapper<merchant> wrapper = new QueryWrapper<>();
        wrapper.eq("account", account).eq("password", password).eq("merchant_category", merchantCategory);
        merchant m = baseMapper.selectOne(wrapper);
        
        if (m != null) {
            String token = "merchant_token_" + UUID.randomUUID().toString().replace("-", "");
            result.put("code", 0);
            result.put("message", "ok");
            
            Map<String, Object> data = new HashMap<>();
            data.put("token", token);
            data.put("loginType", "password");
            data.put("phoneBound", true);
            data.put("phone", m.getPhone() != null ? m.getPhone() : "");
            
            Map<String, Object> profile = new HashMap<>();
            String businessType = m.getBusinessType() != null ? m.getBusinessType() : "default";
            profile.put("merchantId", m.getMerchantId());
            profile.put("merchantName", m.getMerchantName() != null ? m.getMerchantName() : "");
            profile.put("businessType", businessType);
            profile.put("businessLabel", m.getBusinessLabel() != null ? m.getBusinessLabel() : "");
            profile.put("merchantCategory", m.getMerchantCategory() != null ? m.getMerchantCategory() : "");
            profile.put("merchantCategoryLabel", m.getMerchantCategoryLabel() != null ? m.getMerchantCategoryLabel() : "");
            profile.put("dormBuilding", m.getDormBuilding() != null ? m.getDormBuilding() : "");
            profile.put("manager", m.getManager() != null ? m.getManager() : "");
            data.put("profile", profile);
            
            result.put("data", data);
        } else {
            if (dormBuilding != null && merchantCategory != null) {
                merchant newMerchant = new merchant();
                newMerchant.setAccount(account);
                newMerchant.setPassword(password);
                newMerchant.setDormBuilding(dormBuilding);
                newMerchant.setMerchantCategory(merchantCategory);
                
                String categoryLabel = "fruit".equals(merchantCategory) ? "水果店" : "便利店";
                newMerchant.setMerchantCategoryLabel(categoryLabel);
                newMerchant.setMerchantName(dormBuilding + categoryLabel);
                
                newMerchant.setBusinessType("market");
                newMerchant.setBusinessLabel("校园超市");
                newMerchant.setStatus("active");

                if("fruit".equals(merchantCategory)){
                    newMerchant.setBusinessType("fruit");

                }
                
                baseMapper.insert(newMerchant);
                
                String token = "merchant_token_" + UUID.randomUUID().toString().replace("-", "");
                result.put("code", 0);
                result.put("message", "注册并登录成功");
                
                Map<String, Object> data = new HashMap<>();
                data.put("token", token);
                data.put("loginType", "password");
                data.put("phoneBound", true);
                data.put("phone", "");
                
                Map<String, Object> profile = new HashMap<>();
                profile.put("merchantId", newMerchant.getMerchantId());
                profile.put("merchantName", newMerchant.getMerchantName());
                profile.put("businessType", newMerchant.getBusinessType());
                profile.put("businessLabel", newMerchant.getBusinessLabel());
                profile.put("merchantCategory", newMerchant.getMerchantCategory());
                profile.put("merchantCategoryLabel", newMerchant.getMerchantCategoryLabel());
                profile.put("dormBuilding", newMerchant.getDormBuilding());
                profile.put("manager", "");
                data.put("profile", profile);
                
                result.put("data", data);
            } else {
                result.put("code", 1);
                result.put("message", "账号或密码错误");
            }
        }
        
        return result;
    }

    @Override
    public Map<String, Object> wechatLogin(String code) {
        Map<String, Object> result = new HashMap<>();
        String loginToken = "wechat_temp_" + UUID.randomUUID().toString().replace("-", "");
        
        result.put("code", 0);
        result.put("message", "ok");
        
        Map<String, Object> data = new HashMap<>();
        data.put("loginToken", loginToken);
        data.put("openid", "wx_openid_" + System.currentTimeMillis());
        data.put("phoneBound", false);
        
        Map<String, Object> profile = new HashMap<>();
        profile.put("merchantId", "");
        profile.put("merchantName", "");
        profile.put("businessType", "");
        data.put("profile", profile);
        
        result.put("data", data);
        return result;
    }

    @Override
    public Map<String, Object> bindPhone(String loginToken, String phoneCode, String businessType, String merchantCategory) {
        Map<String, Object> result = new HashMap<>();
        
        merchant m = getMerchantByBusinessType(businessType);
        String token = "merchant_token_" + UUID.randomUUID().toString().replace("-", "");
        
        result.put("code", 0);
        result.put("message", "ok");
        
        Map<String, Object> data = new HashMap<>();
        data.put("token", token);
        data.put("loginType", "wechat");
        data.put("phoneBound", true);
        data.put("phone", "13800000000");
        
        Map<String, Object> profile = new HashMap<>();
        if (m != null) {
            profile.put("merchantId", "M-" + m.getBusinessType().toUpperCase().replace("-", "-"));
            profile.put("merchantName", m.getMerchantName());
            profile.put("businessType", m.getBusinessType());
            profile.put("businessLabel", m.getBusinessLabel());
            profile.put("merchantCategory", m.getMerchantCategory());
            profile.put("merchantCategoryLabel", m.getMerchantCategoryLabel());
            profile.put("dormBuilding", m.getDormBuilding());
            profile.put("manager", m.getManager());
        } else {
            profile.put("merchantId", "M-" + businessType.toUpperCase());
            profile.put("merchantName", businessType);
            profile.put("businessType", businessType);
            profile.put("businessLabel", businessType);
            profile.put("merchantCategory", merchantCategory);
            profile.put("merchantCategoryLabel", merchantCategory.equals("convenience") ? "便利店商家" : "水果商家");
            profile.put("dormBuilding", businessType);
            profile.put("manager", businessType + "管理员");
        }
        data.put("profile", profile);
        
        result.put("data", data);
        return result;
    }

    @Override
    public merchant getMerchantByBusinessType(String businessType) {
        QueryWrapper<merchant> wrapper = new QueryWrapper<>();
        wrapper.eq("business_type", businessType);
        return baseMapper.selectOne(wrapper);
    }
}
