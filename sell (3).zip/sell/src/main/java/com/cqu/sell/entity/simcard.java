package com.cqu.sell.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.*;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@TableName("simcard")
public class simcard {
    @TableId(value="id",type=IdType.AUTO)
    private Integer id;

    private String name;
    private Integer price;
    private String data;
    private String calls;
    private String features;
    private Boolean recommended;
}