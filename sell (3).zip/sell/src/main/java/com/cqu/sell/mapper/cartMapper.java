package com.cqu.sell.mapper;

import com.cqu.sell.entity.cart;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface cartMapper extends BaseMapper<cart> {
}