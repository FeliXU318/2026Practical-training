package com.cqu.sell.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.cqu.sell.entity.product;
import com.cqu.sell.mapper.productMapper;
import com.cqu.sell.service.productService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

import java.util.List;



@Service
public class productServiceImpl extends ServiceImpl<productMapper, product> implements productService {

    @Override
    public List<product> findAll() {
        QueryWrapper<product> wrapper = new QueryWrapper<>();
        return baseMapper.selectList(wrapper);
    }

    @Override
    public List<product> findProductByName(String name){
        QueryWrapper<product> wrapper = new QueryWrapper<>();
        wrapper.like("product_name",name);
        return baseMapper.selectList(wrapper);
    }

    @Override
    public boolean addProduct(product product){
        return this.save(product);
    }

    @Override
    public boolean deleteProduct(int id){
        return this.removeById(id);
    }

    @Override
    public boolean updateProduct(product product){
        return this.updateById(product);
    }

    @Override
    public product getProductById(int id){
        return baseMapper.selectById(id);
    }

    @Override
    public IPage<product> getProductPage(long current,long size){
        Page<product> page=new Page<>(current,size);
        QueryWrapper<product> wrapper=new QueryWrapper<>();
        wrapper.orderByAsc("product_id");
        return this.page(page,wrapper);
    }
}
