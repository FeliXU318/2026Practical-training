package com.cqu.sell.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.*;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@TableName("merchant")
public class merchant {
    @TableId(value="merchant_id",type=IdType.AUTO)
    private Integer merchantId;

    @TableField(value="merchant_name")
    private String merchantName;

    @TableField(value="merchant_role")
    private String merchantRole;

    @TableField(value="contact_phone")
    private String contactPhone;

    private String status;

    @TableField(value="business_type")
    private String businessType;

    @TableField(value="business_label")
    private String businessLabel;

    @TableField(value="merchant_category")
    private String merchantCategory;

    @TableField(value="merchant_category_label")
    private String merchantCategoryLabel;

    @TableField(value="dorm_building")
    private String dormBuilding;

    private String manager;

    private String phone;

    private String account;

    private String password;
}
