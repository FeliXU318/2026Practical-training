package com.cqu.sell.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.cqu.sell.entity.user;
import com.cqu.sell.service.userService;
import java.util.HashMap;
import java.util.Map;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/user")
public class userController {

    @Autowired
    private userService userService;

    @GetMapping("/login")
    public Map<String,Object> login(@RequestParam String phone, @RequestParam(required = false) String password, @RequestParam(required = false) String code){
        Map<String,Object> result = new HashMap<>();
        
        if (code != null && !code.isEmpty()) {
            result.put("success", true);
            result.put("message", "登录成功");
            result.put("userId", 1);
            result.put("username", "微信用户");
            return result;
        }
        
        boolean success = userService.login(phone, password);
        result.put("success", success);


        if(success){
            user user=userService.getUserByPhone(phone);
            result.put("message","登录成功");
            result.put("userId", user.getUserId());
            result.put("username", user.getNickname());
            result.put("avatar", user.getAvatar());
            result.put("city", user.getCity());
            Integer userId=user.getUserId();
            String token = "token_"+userId.toString();
            result.put("token",token);
        }else{
            result.put("message","账号或密码错误");
        }

        return result;
    }

    @PostMapping("/register")
    public Map<String,Object> register(@RequestParam String phone, @RequestParam String password, @RequestParam String username, @RequestParam(required = false) String avatar){
        user user = new user();
        user.setPhone(phone);
        user.setPassword(password);
        user.setNickname(username);
        user.setAvatar(avatar != null ? avatar : "");
        user.setCity("校园用户");
        
        boolean success = userService.register(user);
        Map<String,Object> result = new HashMap<>();
        result.put("success",success);
        if(success){
            result.put("message","注册成功");
        } else {
            result.put("message","该手机号已注册");
        }
        return result;
    }

    @GetMapping("/profile")
    public Map<String,Object> profile(@RequestHeader(value = "Authorization", required = false) String token){
        Map<String,Object> result = new HashMap<>();
        
        if (token == null || !token.startsWith("Bearer ")) {
            result.put("success", false);
            result.put("message", "未登录");
            return result;
        }
        
        String userId = token.substring(7).replace("token_", "");
        user user = userService.getById(Integer.parseInt(userId));
        
        if (user != null) {
            result.put("success", true);
            result.put("userId", user.getUserId());
            result.put("username", user.getNickname());
            result.put("avatar", user.getAvatar());
            result.put("phone", user.getPhone());
            result.put("city", user.getCity());
        } else {
            result.put("success", false);
            result.put("message", "用户不存在");
        }
        
        return result;
    }

    @PutMapping("/profile")
    public Map<String,Object> updateProfile(@RequestHeader(value = "Authorization") String token, @RequestBody Map<String, String> body){
        Map<String,Object> result = new HashMap<>();
        
        String userId = token.substring(7).replace("token_", "");
        user user = userService.getById(Integer.parseInt(userId));
        
        if (user != null) {
            if (body.containsKey("username")) {
                user.setNickname(body.get("username"));
            }
            if (body.containsKey("avatar")) {
                user.setAvatar(body.get("avatar"));
            }
            if (body.containsKey("city")) {
                user.setCity(body.get("city"));
            }
            userService.updateById(user);
            result.put("success", true);
            result.put("message", "更新成功");
        } else {
            result.put("success", false);
            result.put("message", "用户不存在");
        }
        
        return result;
    }

    @PostMapping("/logout")
    public Map<String,Object> logout(@RequestHeader(value = "Authorization") String token){
        Map<String,Object> result = new HashMap<>();
        result.put("success", true);
        result.put("message", "退出成功");
        return result;
    }
}