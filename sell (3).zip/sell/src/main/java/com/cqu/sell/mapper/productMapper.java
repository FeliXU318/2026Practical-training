package com.cqu.sell.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.cqu.sell.entity.product;

public interface productMapper extends BaseMapper<product>{

}
