package com.cqu.sell.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.cqu.sell.entity.product;
import com.baomidou.mybatisplus.extension.service.IService;
import java.util.List;

public interface productService extends IService<product>{
    List<product> findAll();

    List<product> findProductByName(String name);

    boolean addProduct(product product);

    boolean deleteProduct(int product_id);

    boolean updateProduct(product product);

    product getProductById(int product_id);

    IPage<product> getProductPage(long current,long size);

}
