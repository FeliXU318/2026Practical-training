package com.cqu.sell.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.cqu.sell.entity.order;
import com.baomidou.mybatisplus.extension.service.IService;
import java.util.List;

public interface orderService extends IService<order>{
    List<order> findUserOrder(String userId);

    List<order> findMerchantOrder(String merchantId);

    boolean addOrder(order order);

    boolean deleteOrder(int order_id);

    boolean updateOrderAddress(int order_id, String address);

    order getOrderById(int order_id);

    IPage<order> getOrderPage(long current, long size);

    boolean updateOrderStatus(int order_id, String status);
}
