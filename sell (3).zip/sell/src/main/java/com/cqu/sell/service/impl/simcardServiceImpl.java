package com.cqu.sell.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.cqu.sell.entity.order;
import com.cqu.sell.entity.simcard;
import com.cqu.sell.mapper.simcardMapper;
import com.cqu.sell.mapper.orderMapper;
import com.cqu.sell.service.simcardService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class simcardServiceImpl extends ServiceImpl<simcardMapper, simcard> implements simcardService {

    private final orderMapper orderMapper;

    public simcardServiceImpl(orderMapper orderMapper) {
        this.orderMapper = orderMapper;
    }

    @Override
    public List<simcard> getPlans() {
        QueryWrapper<simcard> wrapper = new QueryWrapper<>();
        return baseMapper.selectList(wrapper);
    }

    @Override
    public Integer apply(Integer userId, Integer planId, String name, String phone, String idCard, String address) {
        simcard plan = baseMapper.selectById(planId);
        if (plan == null) {
            return null;
        }
        
        order order = new order();
        order.setUserId(userId);
        order.setOrderType("电话卡");
        order.setTitle(plan.getName() + "办理");
        order.setContent("姓名: " + name + ", 手机号: " + phone);
        order.setReward(plan.getPrice());
        order.setOrderStatus("待支付");
        order.setStatusClass("status-pay");
        order.setTime(java.time.LocalDateTime.now().format(java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));
        order.setLocation(address);
        order.setColor("#9C27B0");
        order.setRewarded(false);
        
        orderMapper.insert(order);
        
        return order.getOrderId();
    }
}