package com.cqu.sell.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.cqu.sell.entity.chat;
import com.cqu.sell.entity.chatSession;
import com.baomidou.mybatisplus.extension.service.IService;
import java.util.List;
import java.util.Map;

public interface chatService extends IService<chat>{

    List<Map<String, Object>> getSessions(Integer userId);

    Map<String, Object> createOrGetSession(Integer userId, Integer targetId);

    boolean deleteSession(Integer userId, String sessionKey);

    boolean markRead(Integer userId, String sessionKey);

    List<Map<String, Object>> getMessages(String sessionKey, Integer page, Integer size);

    Map<String, Object> sendMessage(Integer userId, String sessionKey, Integer receiverId, String content, String type);

    List<Map<String, Object>> searchUser(String keyword);

}