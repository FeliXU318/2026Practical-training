package com.cqu.sell.controller;

import com.cqu.sell.entity.secondhand;
import com.cqu.sell.service.secondhandService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/secondhand")
public class secondhandController {

    @Autowired
    private secondhandService secondhandService;

    @GetMapping("/list")
    public Map<String,Object> list(@RequestParam(required = false) String category, @RequestParam(required = false) String keyword){
        Map<String,Object> result = new HashMap<>();
        
        List<secondhand> goodsList = secondhandService.getGoodsList(category, keyword);
        
        List<Map<String, Object>> list = new ArrayList<>();
        for (secondhand goods : goodsList) {
            Map<String, Object> item = new HashMap<>();
            item.put("id", goods.getId());
            item.put("title", goods.getTitle());
            item.put("price", goods.getPrice());
            item.put("originalPrice", goods.getOriginalPrice());
            item.put("image", goods.getImage());
            item.put("seller", goods.getSeller());
            item.put("campus", goods.getCampus());
            item.put("time", goods.getTime());
            item.put("category", goods.getCategory());
            list.add(item);
        }
        
        result.put("success", true);
        result.put("list", list);
        return result;
    }

    @GetMapping("/detail")
    public Map<String,Object> detail(@RequestParam Integer id){
        Map<String,Object> result = new HashMap<>();
        
        secondhand goods = secondhandService.getGoodsById(id);
        if (goods != null) {
            result.put("success", true);
            result.put("id", goods.getId());
            result.put("title", goods.getTitle());
            result.put("price", goods.getPrice());
            result.put("originalPrice", goods.getOriginalPrice());
            result.put("image", goods.getImage());
            result.put("seller", goods.getSeller());
            result.put("campus", goods.getCampus());
            result.put("time", goods.getTime());
            result.put("category", goods.getCategory());
            result.put("description", goods.getDescription());
            result.put("user_id", goods.getUserId());
        } else {
            result.put("success", false);
            result.put("message", "商品不存在");
        }
        
        return result;
    }

    @PostMapping("/publish")
    public Map<String,Object> publish(@RequestHeader(value = "Authorization") String token, @RequestBody Map<String, Object> body){
        Map<String,Object> result = new HashMap<>();
        
        String userId = token.substring(7).replace("token_", "");
        int user_id=Integer.parseInt(userId);
        String title = (String) body.get("title");
        Double price = toDouble(body.get("price"));
        Double originalPrice = toDouble(body.get("originalPrice"));
        String image = (String) body.get("image");
        String category = (String) body.get("category");
        String campus = (String) body.get("campus");
        String description = (String) body.get("description");
        String time = (String) body.get("time");
        String seller = (String) body.get("seller");
        
        secondhand goods = secondhandService.publishGoods(user_id, title, price, originalPrice, image, seller, category, campus, description,time);
        
        Map<String, Object> goodsMap = new HashMap<>();
        goodsMap.put("id", goods.getId());
        
        result.put("success", true);
        result.put("message", "发布成功");
        result.put("goods", goodsMap);
        return result;
    }

    @PostMapping("/buy")
    public Map<String,Object> buy(@RequestHeader(value = "Authorization") String token, @RequestBody Map<String, Integer> body){
        Map<String,Object> result = new HashMap<>();
        
        String userId = token.substring(7).replace("token_", "");
        int user_id = Integer.parseInt(userId);

        Integer goodsId = body.get("goodsId");
        
        Integer orderId = secondhandService.buyGoods(user_id, goodsId);
        if (orderId != null) {
            result.put("success", true);
            result.put("message", "购买成功");
            result.put("orderId", orderId);
        } else {
            result.put("success", false);
            result.put("message", "购买失败");
        }
        
        return result;
    }

    private Double toDouble(Object value) {
        if (value == null) {
            return null;
        }
        if (value instanceof Double) {
            return (Double) value;
        }
        if (value instanceof Integer) {
            return ((Integer) value).doubleValue();
        }
        if (value instanceof Number) {
            return ((Number) value).doubleValue();
        }
        return Double.parseDouble(value.toString());
    }
}