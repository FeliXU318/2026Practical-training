package com.cqu.sell.mapper;

import com.cqu.sell.entity.secondhand;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface secondhandMapper extends BaseMapper<secondhand> {
}