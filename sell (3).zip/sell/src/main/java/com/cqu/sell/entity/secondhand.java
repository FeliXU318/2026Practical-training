package com.cqu.sell.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.*;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@TableName("secondhand")
public class secondhand {
    @TableId(value="id",type=IdType.AUTO)
    private Integer id;

    @TableField(value="user_id")
    private Integer userId;

    private String title;
    private Double price;

    @TableField(value="original_price")
    private Double originalPrice;
    private String image;
    private String seller;
    private String campus;
    private String time;
    private String category;
    private String description;
    private Boolean sold;
}