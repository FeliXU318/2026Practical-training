package com.cqu.sell.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.cqu.sell.entity.order;

public interface orderMapper extends BaseMapper<order> {

}
