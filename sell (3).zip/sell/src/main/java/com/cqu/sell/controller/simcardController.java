package com.cqu.sell.controller;

import com.cqu.sell.entity.simcard;
import com.cqu.sell.service.simcardService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/simcard")
public class simcardController {

    @Autowired
    private simcardService simcardService;

    @GetMapping("/plans")
    public Map<String,Object> plans(){
        Map<String,Object> result = new HashMap<>();
        
        List<simcard> plans = simcardService.getPlans();
        
        List<Map<String, Object>> list = new ArrayList<>();
        for (simcard plan : plans) {
            Map<String, Object> item = new HashMap<>();
            item.put("id", plan.getId());
            item.put("name", plan.getName());
            item.put("price", plan.getPrice());
            item.put("data", plan.getData());
            item.put("calls", plan.getCalls());
            item.put("features", plan.getFeatures() != null ? plan.getFeatures().split(",") : new String[0]);
            item.put("recommended", plan.getRecommended());
            list.add(item);
        }
        
        result.put("success", true);
        result.put("list", list);
        return result;
    }

    @PostMapping("/apply")
    public Map<String,Object> apply(@RequestHeader(value = "Authorization") String token, @RequestBody Map<String, Object> body){
        Map<String,Object> result = new HashMap<>();
        
        String userId = token.substring(7).replace("token_", "");
        int user_id = Integer.parseInt(userId);

        Integer planId = (Integer) body.get("planId");
        String name = (String) body.get("name");
        String phone = (String) body.get("phone");
        String idCard = (String) body.get("idCard");
        String address = (String) body.get("address");
        
        Integer orderId = simcardService.apply(user_id, planId, name, phone, idCard, address);
        if (orderId != null) {
            result.put("success", true);
            result.put("message", "提交成功");
            result.put("orderId", orderId);
        } else {
            result.put("success", false);
            result.put("message", "提交失败");
        }
        
        return result;
    }
}