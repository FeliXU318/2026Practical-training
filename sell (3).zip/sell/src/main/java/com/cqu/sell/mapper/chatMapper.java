package com.cqu.sell.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.cqu.sell.entity.chat;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface chatMapper extends BaseMapper<chat>{

}
