package com.cqu.sell.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.*;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@TableName("aftersale")
public class aftersale {
    @TableId(value="id",type=IdType.AUTO)
    private Integer id;

    @TableField(value="after_sale_id")
    private String afterSaleId;

    @TableField(value="order_id")
    private Integer orderId;

    @TableField(value="order_title")
    private String orderTitle;

    @TableField(value="order_content")
    private String orderContent;

    @TableField(value="order_reward")
    private Double orderReward;

    private String type;

    @TableField(value="type_text")
    private String typeText;
    private String reason;

    @TableField(value="reason_text")
    private String reasonText;

    @TableField(value="reason_desc")
    private String reasonDesc;
    private Double amount;

    @TableField(value="actual_refund")
    private Double actualRefund;
    private String description;
    private String images;
    private String status;

    @TableField(value="status_text")
    private String statusText;

    @TableField(value="create_time")
    private Long createTime;

    @TableField(value="update_time")
    private Long updateTime;
    private String timeline;
    private String company;

    @TableField(value="tracking_no")
    private String trackingNo;


}