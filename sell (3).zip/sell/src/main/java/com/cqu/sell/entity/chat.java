package com.cqu.sell.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.*;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@TableName("chat")
public class chat {

    @TableId(value="chat_id",type=IdType.AUTO)
    private Integer chatId;

    @TableField(value="session_key")
    private String sessionKey;

    @TableField(value="sender_id")
    private Integer senderId;

    @TableField(value="receiver_id")
    private Integer receiverId;

    private String content;

    private String type;

    @TableField(value="sender_role")
    private Integer senderRole;

    @TableField(value="receiver_role")
    private Integer receiverRole;

    @TableField(value="is_read")
    private Integer isRead;

    private Long timestamp;

    @TableField(value="create_time")
    private String createTime;

}