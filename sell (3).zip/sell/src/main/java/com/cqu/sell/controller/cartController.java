package com.cqu.sell.controller;

import com.cqu.sell.entity.cart;
import com.cqu.sell.service.cartService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/cart")
public class cartController {

    @Autowired
    private cartService cartService;

    @GetMapping("/{cartKey}")
    public Map<String,Object> getCart(@RequestHeader(value = "Authorization") String token, @PathVariable String cartKey){
        Map<String,Object> result = new HashMap<>();
        
        String userId = token.substring(7).replace("token_", "");
        List<cart> carts = cartService.getCartByUserAndKey(userId, cartKey);
        
        List<Map<String, Object>> list = new ArrayList<>();
        for (cart c : carts) {
            Map<String, Object> item = new HashMap<>();
            item.put("id", c.getProductId());
            item.put("name", c.getName());
            item.put("price", c.getPrice());
            item.put("image", c.getImage());
            item.put("quantity", c.getQuantity());
            list.add(item);
        }
        
        result.put("success", true);
        result.put("list", list);
        return result;
    }

    @PostMapping("/{cartKey}")
    public Map<String,Object> addToCart(@RequestHeader(value = "Authorization") String token, @PathVariable String cartKey, @RequestBody Map<String, Object> body){
        Map<String,Object> result = new HashMap<>();
        
        String userId = token.substring(7).replace("token_", "");
        Integer productId = (Integer) body.get("id");
        String name = (String) body.get("name");
        Double price = (Double) body.get("price");
        String image = (String) body.get("image");
        
        cartService.addToCart(userId, cartKey, productId, name, price, image);
        
        List<cart> carts = cartService.getCartByUserAndKey(userId, cartKey);
        List<Map<String, Object>> list = new ArrayList<>();
        for (cart c : carts) {
            Map<String, Object> item = new HashMap<>();
            item.put("id", c.getProductId());
            item.put("name", c.getName());
            item.put("price", c.getPrice());
            item.put("image", c.getImage());
            item.put("quantity", c.getQuantity());
            list.add(item);
        }
        
        result.put("success", true);
        result.put("list", list);
        return result;
    }

    @PutMapping("/{cartKey}")
    public Map<String,Object> updateQuantity(@RequestHeader(value = "Authorization") String token, @PathVariable String cartKey, @RequestBody Map<String, Object> body){
        Map<String,Object> result = new HashMap<>();
        
        String userId = token.substring(7).replace("token_", "");
        Integer productId = (Integer) body.get("productId");
        Integer quantity = (Integer) body.get("quantity");
        
        cartService.updateQuantity(userId, cartKey, productId, quantity);
        
        List<cart> carts = cartService.getCartByUserAndKey(userId, cartKey);
        List<Map<String, Object>> list = new ArrayList<>();
        for (cart c : carts) {
            Map<String, Object> item = new HashMap<>();
            item.put("id", c.getProductId());
            item.put("name", c.getName());
            item.put("price", c.getPrice());
            item.put("image", c.getImage());
            item.put("quantity", c.getQuantity());
            list.add(item);
        }
        
        result.put("success", true);
        result.put("list", list);
        return result;
    }

    @DeleteMapping("/{cartKey}")
    public Map<String,Object> clearCart(@RequestHeader(value = "Authorization") String token, @PathVariable String cartKey){
        Map<String,Object> result = new HashMap<>();
        
        String userId = token.substring(7).replace("token_", "");
        cartService.clearCart(userId, cartKey);
        
        result.put("success", true);
        result.put("message", "清空成功");
        return result;
    }
}