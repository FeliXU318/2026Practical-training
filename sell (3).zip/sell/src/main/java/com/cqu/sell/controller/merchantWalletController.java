package com.cqu.sell.controller;

import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/merchant/wallet")
public class merchantWalletController {

    @GetMapping
    public Map<String, Object> wallet(@RequestParam String businessType) {
        Map<String, Object> result = new HashMap<>();
        
        List<Map<String, Object>> records = new ArrayList<>();
        
        Map<String, Object> record1 = new HashMap<>();
        record1.put("id", businessType + "-income-3");
        record1.put("type", "income");
        record1.put("title", "订单结算");
        record1.put("amount", 328.6);
        record1.put("status", "已入账");
        record1.put("createdAt", "今天 09:20");
        records.add(record1);
        
        Map<String, Object> record2 = new HashMap<>();
        record2.put("id", businessType + "-withdraw-2");
        record2.put("type", "withdraw");
        record2.put("title", "提现至微信零钱");
        record2.put("amount", -500);
        record2.put("status", "已到账");
        record2.put("createdAt", "06-29 16:45");
        records.add(record2);
        
        Map<String, Object> data = new HashMap<>();
        data.put("businessType", businessType);
        data.put("availableBalance", 2680.5);
        data.put("pendingSettlement", 328.6);
        data.put("totalWithdrawn", 12600);
        data.put("records", records);
        
        result.put("code", 0);
        result.put("message", "ok");
        result.put("data", data);
        return result;
    }

    @PostMapping("/withdraw")
    public Map<String, Object> withdraw(@RequestBody Map<String, Object> body) {
        Map<String, Object> result = new HashMap<>();
        String businessType = (String) body.get("businessType");
        Double amount = ((Number) body.get("amount")).doubleValue();
        
        if (amount < 1) {
            result.put("code", 1);
            result.put("message", "最低提现金额为 1 元");
            return result;
        }
        
        if (amount > 2680.5) {
            result.put("code", 1);
            result.put("message", "提现金额不能超过可提现余额");
            return result;
        }
        
        List<Map<String, Object>> records = new ArrayList<>();
        
        Map<String, Object> newRecord = new HashMap<>();
        newRecord.put("id", "withdraw-" + System.currentTimeMillis());
        newRecord.put("type", "withdraw");
        newRecord.put("title", "提现至微信零钱");
        newRecord.put("amount", -amount);
        newRecord.put("status", "处理中");
        newRecord.put("createdAt", "刚刚");
        records.add(newRecord);
        
        Map<String, Object> data = new HashMap<>();
        data.put("businessType", businessType);
        data.put("availableBalance", 2680.5 - amount);
        data.put("pendingSettlement", 328.6);
        data.put("totalWithdrawn", 12600 + amount);
        data.put("records", records);
        
        result.put("code", 0);
        result.put("message", "ok");
        result.put("data", data);
        return result;
    }
}