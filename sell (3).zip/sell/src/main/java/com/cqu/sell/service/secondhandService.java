package com.cqu.sell.service;

import com.cqu.sell.entity.secondhand;
import com.baomidou.mybatisplus.extension.service.IService;
import java.util.List;

public interface secondhandService extends IService<secondhand> {
    List<secondhand> getGoodsList(String category, String keyword);
    secondhand getGoodsById(Integer id);
    secondhand publishGoods(Integer userId, String title, Double price, Double originalPrice, String image, String seller,String category, String campus, String description,String time);
    Integer buyGoods(Integer userId, Integer goodsId);
}