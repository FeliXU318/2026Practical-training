package com.cqu.sell.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.*;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@TableName("member")
public class member {
    @TableId(value="id",type=IdType.AUTO)
    private Integer id;

    @TableField(value="user_id")
    private Integer userId;

    private String level;

    @TableField(value="level_name")
    private String levelName;
    private Integer points;
    private Integer growth;

    @TableField(value="total_spend")
    private Double totalSpend;

    @TableField(value="checkin_date")
    private String checkinDate;

    @TableField(value="continuous_checkin")
    private Integer continuousCheckin;
}