package com.cqu.sell.controller;

import com.cqu.sell.entity.aftersale;
import com.cqu.sell.service.aftersaleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/order/aftersale")
public class aftersaleController {

    @Autowired
    private aftersaleService aftersaleService;

    @PostMapping("/apply")
    public Map<String,Object> apply(@RequestHeader(value = "Authorization") String token, @RequestBody Map<String, Object> body){
        Map<String,Object> result = new HashMap<>();

        String userId = token.substring(7).replace("token_", "");
        int user_id=Integer.parseInt(userId);
        Integer orderId = (Integer) body.get("orderId");
        String type = (String) body.get("type");
        String reason = (String) body.get("reason");
        String reasonDesc = (String) body.get("reasonDesc");
        Object amountObj = body.get("amount");
        Double amount = amountObj == null ? null : Double.parseDouble(amountObj.toString());
        List<String> images = (List<String>) body.get("images");
        String description = (String) body.get("description");

        String afterSaleId = aftersaleService.apply(user_id, orderId, type, reason, reasonDesc, amount, images != null ? String.join(",", images) : "", description);

        if (afterSaleId != null) {
            result.put("success", true);
            result.put("message", "申请已提交");
            result.put("afterSaleId", afterSaleId);
        } else {
            result.put("success", false);
            result.put("message", "申请失败");
        }

        return result;
    }

    @GetMapping("/list")
    public Map<String,Object> list(@RequestHeader(value = "Authorization") String token, @RequestParam(required = false) String status){
        Map<String,Object> result = new HashMap<>();

        String userId = token.substring(7).replace("token_", "");
        int user_id=Integer.parseInt(userId);
        List<aftersale> aftersales = aftersaleService.getList(user_id, status);

        List<Map<String, Object>> list = new ArrayList<>();
        for (aftersale a : aftersales) {
            Map<String, Object> item = new HashMap<>();
            item.put("afterSaleId", a.getAfterSaleId());
            item.put("orderId", a.getOrderId());
            item.put("orderTitle", a.getOrderTitle());
            item.put("orderContent", a.getOrderContent());
            item.put("orderReward", a.getOrderReward());
            item.put("type", a.getType());
            item.put("typeText", a.getTypeText());
            item.put("reason", a.getReason());
            item.put("reasonText", a.getReasonText());
            item.put("reasonDesc", a.getReasonDesc());
            item.put("amount", a.getAmount());
            item.put("actualRefund", a.getActualRefund());
            item.put("description", a.getDescription());
            item.put("images", a.getImages() != null ? a.getImages().split(",") : new String[0]);
            item.put("status", a.getStatus());
            item.put("statusText", a.getStatusText());
            item.put("createTime", a.getCreateTime());
            item.put("updateTime", a.getUpdateTime());
            list.add(item);
        }

        result.put("success", true);
        result.put("list", list);
        return result;
    }

    @GetMapping("/detail")
    public Map<String,Object> detail(@RequestHeader(value = "Authorization") String token, @RequestParam String afterSaleId){
        Map<String,Object> result = new HashMap<>();

        aftersale aftersale = aftersaleService.getDetail(afterSaleId);
        if (aftersale != null) {
            result.put("success", true);
            result.put("afterSaleId", aftersale.getAfterSaleId());
            result.put("orderId", aftersale.getOrderId());
            result.put("orderTitle", aftersale.getOrderTitle());
            result.put("orderContent", aftersale.getOrderContent());
            result.put("orderReward", aftersale.getOrderReward());
            result.put("type", aftersale.getType());
            result.put("typeText", aftersale.getTypeText());
            result.put("reason", aftersale.getReason());
            result.put("reasonText", aftersale.getReasonText());
            result.put("reasonDesc", aftersale.getReasonDesc());
            result.put("amount", aftersale.getAmount());
            result.put("actualRefund", aftersale.getActualRefund());
            result.put("description", aftersale.getDescription());
            result.put("images", aftersale.getImages() != null ? aftersale.getImages().split(",") : new String[0]);
            result.put("status", aftersale.getStatus());
            result.put("statusText", aftersale.getStatusText());
            result.put("createTime", aftersale.getCreateTime());
            result.put("updateTime", aftersale.getUpdateTime());
        } else {
            result.put("success", false);
            result.put("message", "售后单不存在");
        }

        return result;
    }

    @PostMapping("/cancel")
    public Map<String,Object> cancel(@RequestHeader(value = "Authorization") String token, @RequestBody Map<String, String> body){
        Map<String,Object> result = new HashMap<>();

        String afterSaleId = body.get("afterSaleId");
        boolean success = aftersaleService.cancel(afterSaleId);

        if (success) {
            result.put("success", true);
            result.put("message", "已撤销");
        } else {
            result.put("success", false);
            result.put("message", "撤销失败");
        }

        return result;
    }

    @PostMapping("/ship")
    public Map<String,Object> ship(@RequestHeader(value = "Authorization") String token, @RequestBody Map<String, String> body){
        Map<String,Object> result = new HashMap<>();

        String afterSaleId = body.get("afterSaleId");
        String company = body.get("company");
        String trackingNo = body.get("trackingNo");

        boolean success = aftersaleService.ship(afterSaleId, company, trackingNo);

        if (success) {
            result.put("success", true);
            result.put("message", "已提交物流信息");
        } else {
            result.put("success", false);
            result.put("message", "提交失败");
        }

        return result;
    }
}