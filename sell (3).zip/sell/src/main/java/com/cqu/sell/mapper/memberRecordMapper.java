package com.cqu.sell.mapper;

import com.cqu.sell.entity.memberRecord;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface memberRecordMapper extends BaseMapper<memberRecord> {
}