package com.cqu.sell.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.*;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@TableName("product")
public class product {
    @TableId(value="product_id",type=IdType.AUTO)
    private Integer productId;

    @TableField(value="merchant_id")
    private Integer merchantId;

    @TableField(value="product_name")
    private String productName;
    private String category;
    private float price;

    @TableField(value="original_price")
    private float originalPrice;
    private Integer sales;
    private Integer stock;
    private String image;
    private String unit;
    private String tag;

    @TableField(value="category_id")
    private Integer categoryId;

    @TableField(value="product_type")
    private String productType;
}
