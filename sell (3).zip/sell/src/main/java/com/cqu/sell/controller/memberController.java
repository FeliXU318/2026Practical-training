package com.cqu.sell.controller;

import com.cqu.sell.entity.member;
import com.cqu.sell.service.memberService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/member")
public class memberController {

    @Autowired
    private memberService memberService;

    @GetMapping("/info")
    public Map<String,Object> info(@RequestHeader(value = "Authorization") String token){
        Map<String,Object> result = new HashMap<>();
        
        String userId = token.substring(7).replace("token_", "");
        int user_id=Integer.parseInt(userId);
        member member = memberService.getMemberByUserId(user_id);
        
        result.put("success", true);
        result.put("level", member.getLevel());
        result.put("levelName", member.getLevelName());
        result.put("points", member.getPoints());
        result.put("growth", member.getGrowth());
        result.put("totalSpend", member.getTotalSpend());
        result.put("checkinDate", member.getCheckinDate());
        result.put("continuousCheckin", member.getContinuousCheckin());
        return result;
    }

    @PostMapping("/checkin")
    public Map<String,Object> checkin(@RequestHeader(value = "Authorization") String token){
        String userId = token.substring(7).replace("token_", "");
        int user_id=Integer.parseInt(userId);
        return memberService.checkin(user_id);
    }

    @PostMapping("/share")
    public Map<String,Object> share(@RequestHeader(value = "Authorization") String token){
        String userId = token.substring(7).replace("token_", "");
        int user_id=Integer.parseInt(userId);
        return memberService.share(user_id);
    }

    @PostMapping("/review")
    public Map<String,Object> review(@RequestHeader(value = "Authorization") String token, @RequestBody Map<String, Integer> body){
        String userId = token.substring(7).replace("token_", "");
        int user_id=Integer.parseInt(userId);
        Integer orderId = body.get("orderId");
        return memberService.review(user_id, orderId);
    }

    @PostMapping("/usePoints")
    public Map<String,Object> usePoints(@RequestHeader(value = "Authorization") String token, @RequestBody Map<String, Object> body){
        String userId = token.substring(7).replace("token_", "");
        int user_id=Integer.parseInt(userId);
        Integer points = (Integer) body.get("points");
        Integer orderId = (Integer) body.get("orderId");
        return memberService.usePoints(user_id, points, orderId);
    }

    @GetMapping("/records")
    public Map<String,Object> records(@RequestHeader(value = "Authorization") String token, @RequestParam(required = false) String type){
        Map<String,Object> result = new HashMap<>();
        
        String userId = token.substring(7).replace("token_", "");
        int user_id=Integer.parseInt(userId);

        List<Map<String, Object>> list = memberService.getRecords(user_id, type);
        
        result.put("success", true);
        result.put("list", list);
        return result;
    }

    @PostMapping("/consume")
    public Map<String,Object> consume(@RequestHeader(value = "Authorization") String token, @RequestBody Map<String, Object> body){
        String userId = token.substring(7).replace("token_", "");
        int user_id=Integer.parseInt(userId);
        Object amountObj = body.get("amount");
        Double amount = amountObj == null ? null : ((Number) amountObj).doubleValue();
        Integer orderId = (Integer) body.get("orderId");
        return memberService.consume(user_id, amount, orderId);
    }
}