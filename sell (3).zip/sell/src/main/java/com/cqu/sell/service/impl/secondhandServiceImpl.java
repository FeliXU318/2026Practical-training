package com.cqu.sell.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.cqu.sell.entity.order;
import com.cqu.sell.entity.secondhand;
import com.cqu.sell.mapper.secondhandMapper;
import com.cqu.sell.mapper.orderMapper;
import com.cqu.sell.service.secondhandService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class secondhandServiceImpl extends ServiceImpl<secondhandMapper, secondhand> implements secondhandService {

    private final orderMapper orderMapper;

    public secondhandServiceImpl(orderMapper orderMapper) {
        this.orderMapper = orderMapper;
    }

    @Override
    public List<secondhand> getGoodsList(String category, String keyword) {
        QueryWrapper<secondhand> wrapper = new QueryWrapper<>();
        wrapper.eq("sold", false);
        if (category != null && !category.isEmpty()) {
            wrapper.eq("category", category);
        }
        if (keyword != null && !keyword.isEmpty()) {
            wrapper.like("title", keyword);
        }
        wrapper.orderByDesc("time");
        return baseMapper.selectList(wrapper);
    }

    @Override
    public secondhand getGoodsById(Integer id) {
        return baseMapper.selectById(id);
    }

    @Override
    public secondhand publishGoods(Integer userId, String title, Double price, Double originalPrice, String image,String seller,String category, String campus, String description,String time) {
        secondhand goods = new secondhand();
        goods.setUserId(userId);
        goods.setTitle(title);
        goods.setPrice(price);
        goods.setOriginalPrice(originalPrice);
        goods.setImage(image);
        goods.setSeller(seller);
        goods.setCategory(category);
        goods.setCampus(campus);
        goods.setDescription(description);
        goods.setSold(false);
        goods.setTime(time);
        this.save(goods);
        return goods;
    }

    @Override
    public Integer buyGoods(Integer userId, Integer goodsId) {
        secondhand goods = baseMapper.selectById(goodsId);
        if (goods != null && !goods.getSold()) {
            goods.setSold(true);
            this.updateById(goods);
            
            order order = new order();
            order.setUserId(userId);
            order.setOrderType("二手");
            order.setTitle(goods.getTitle());
            order.setContent(goods.getDescription());
            order.setReward(goods.getPrice());
            order.setOrderStatus("待支付");
            order.setStatusClass("status-pay");
            order.setTime(java.time.LocalDateTime.now().format(java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));
            order.setLocation(goods.getCampus());
            order.setColor("#2196F3");
            order.setRewarded(false);
            
            orderMapper.insert(order);
            
            return order.getOrderId();
        }
        return null;
    }
}