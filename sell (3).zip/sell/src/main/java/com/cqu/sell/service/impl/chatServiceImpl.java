package com.cqu.sell.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.cqu.sell.entity.chat;
import com.cqu.sell.entity.chatSession;
import com.cqu.sell.entity.user;
import com.cqu.sell.mapper.chatSessionMapper;
import com.cqu.sell.mapper.userMapper;
import com.cqu.sell.service.chatService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.cqu.sell.mapper.chatMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.*;

@Service
public class chatServiceImpl extends ServiceImpl<chatMapper, chat> implements chatService {

    @Autowired
    private chatSessionMapper sessionMapper;

    @Autowired
    private userMapper userMapper;

    @Override
    public List<Map<String, Object>> getSessions(Integer userId) {
        QueryWrapper<chatSession> wrapper = new QueryWrapper<>();
        wrapper.eq("user_id", userId).orderByDesc("update_time");
        List<chatSession> sessions = sessionMapper.selectList(wrapper);
        
        List<Map<String, Object>> result = new ArrayList<>();
        for (chatSession session : sessions) {
            Map<String, Object> map = new HashMap<>();
            map.put("id", session.getSessionKey());
            map.put("type", session.getType());
            map.put("targetId", session.getTargetId());
            map.put("targetName", session.getTargetName());
            map.put("targetAvatar", session.getTargetAvatar());
            map.put("lastMessage", session.getLastMessage());
            map.put("lastTime", session.getLastTime());
            map.put("unread", session.getUnread());
            result.add(map);
        }
        return result;
    }

    @Override
    public Map<String, Object> createOrGetSession(Integer userId, Integer targetId) {
        String sessionKey = generateSessionKey(userId, targetId);
        
        QueryWrapper<chatSession> wrapper = new QueryWrapper<>();
        wrapper.eq("user_id", userId).eq("target_id", targetId);
        chatSession session = sessionMapper.selectOne(wrapper);
        
        if (session != null) {
            Map<String, Object> map = new HashMap<>();
            map.put("id", session.getSessionKey());
            map.put("type", session.getType());
            map.put("targetId", session.getTargetId());
            map.put("targetName", session.getTargetName());
            map.put("targetAvatar", session.getTargetAvatar());
            map.put("lastMessage", session.getLastMessage());
            map.put("lastTime", session.getLastTime());
            map.put("unread", session.getUnread());
            return map;
        }
        
        session = new chatSession();
        session.setSessionKey(sessionKey);
        session.setUserId(userId);
        session.setTargetId(targetId);
        session.setType("user");
        session.setUnread(0);
        
        user targetUser = userMapper.selectById(targetId);
        if (targetUser != null) {
            session.setTargetName(targetUser.getNickname() != null ? targetUser.getNickname() : "用户" + targetId);
            session.setTargetAvatar(targetUser.getAvatar() != null ? targetUser.getAvatar() : "");
        } else {
            session.setTargetName("用户" + targetId);
            session.setTargetAvatar("");
        }
        
        session.setLastMessage("开始聊天吧");
        session.setLastTime(formatTime(new Date()));
        session.setCreateTime(formatTime(new Date()));
        session.setUpdateTime(formatTime(new Date()));
        
        sessionMapper.insert(session);
        
        chatSession targetSession = new chatSession();
        targetSession.setSessionKey(sessionKey);
        targetSession.setUserId(targetId);
        targetSession.setTargetId(userId);
        targetSession.setType("user");
        targetSession.setUnread(0);
        
        user currentUser = userMapper.selectById(userId);
        if (currentUser != null) {
            targetSession.setTargetName(currentUser.getNickname() != null ? currentUser.getNickname() : "用户" + userId);
            targetSession.setTargetAvatar(currentUser.getAvatar() != null ? currentUser.getAvatar() : "");
        } else {
            targetSession.setTargetName("用户" + userId);
            targetSession.setTargetAvatar("");
        }
        
        targetSession.setLastMessage("开始聊天吧");
        targetSession.setLastTime(formatTime(new Date()));
        targetSession.setCreateTime(formatTime(new Date()));
        targetSession.setUpdateTime(formatTime(new Date()));
        
        sessionMapper.insert(targetSession);
        
        Map<String, Object> map = new HashMap<>();
        map.put("id", sessionKey);
        map.put("type", "user");
        map.put("targetId", targetId);
        map.put("targetName", session.getTargetName());
        map.put("targetAvatar", session.getTargetAvatar());
        map.put("lastMessage", "开始聊天吧");
        map.put("lastTime", formatTime(new Date()));
        map.put("unread", 0);
        return map;
    }

    @Override
    public boolean deleteSession(Integer userId, String sessionKey) {
        QueryWrapper<chatSession> wrapper = new QueryWrapper<>();
        wrapper.eq("user_id", userId).eq("session_key", sessionKey);
        int result = sessionMapper.delete(wrapper);
        
        QueryWrapper<chat> chatWrapper = new QueryWrapper<>();
        chatWrapper.eq("session_key", sessionKey);
        baseMapper.delete(chatWrapper);
        
        return result > 0;
    }

    @Override
    public boolean markRead(Integer userId, String sessionKey) {
        QueryWrapper<chatSession> wrapper = new QueryWrapper<>();
        wrapper.eq("user_id", userId).eq("session_key", sessionKey);
        chatSession session = sessionMapper.selectOne(wrapper);
        
        if (session != null) {
            session.setUnread(0);
            sessionMapper.updateById(session);
            
            QueryWrapper<chat> chatWrapper = new QueryWrapper<>();
            chatWrapper.eq("session_key", sessionKey).eq("receiver_id", userId);
            chat chatMsg = new chat();
            chatMsg.setIsRead(1);
            baseMapper.update(chatMsg, chatWrapper);
            
            return true;
        }
        return false;
    }

    @Override
    public List<Map<String, Object>> getMessages(String sessionKey, Integer page, Integer size) {
        QueryWrapper<chat> wrapper = new QueryWrapper<>();
        wrapper.eq("session_key", sessionKey).orderByDesc("timestamp");
        
        int offset = (page - 1) * size;
        List<chat> messages = baseMapper.selectList(wrapper);
        
        List<Map<String, Object>> result = new ArrayList<>();
        for (chat msg : messages) {
            Map<String, Object> map = new HashMap<>();
            map.put("id", msg.getChatId());
            map.put("sessionKey", msg.getSessionKey());
            map.put("senderId", msg.getSenderId());
            map.put("receiverId", msg.getReceiverId());
            map.put("content", msg.getContent());
            map.put("type", msg.getType());
            map.put("time", msg.getCreateTime());
            result.add(map);
        }
        
        Collections.reverse(result);
        return result;
    }

    @Override
    public Map<String, Object> sendMessage(Integer userId, String sessionKey, Integer receiverId, String content, String type) {
        chat message = new chat();
        message.setSessionKey(sessionKey);
        message.setSenderId(userId);
        message.setReceiverId(receiverId);
        message.setContent(content);
        message.setType(type != null ? type : "text");
        message.setIsRead(0);
        message.setTimestamp(System.currentTimeMillis());
        message.setCreateTime(formatTime(new Date()));
        
        baseMapper.insert(message);
        
        String displayContent = "text".equals(type) ? content : ("image".equals(type) ? "[图片]" : "[表情]");
        
        QueryWrapper<chatSession> wrapper = new QueryWrapper<>();
        wrapper.eq("user_id", userId).eq("session_key", sessionKey);
        List<chatSession> senderList = sessionMapper.selectList(wrapper);
        chatSession senderSession = senderList.get(0);

        if (senderSession != null) {
            senderSession.setLastMessage(displayContent);
            senderSession.setLastTime(formatTime(new Date()));
            senderSession.setUpdateTime(formatTime(new Date()));
            sessionMapper.updateById(senderSession);
        }
        
        wrapper.clear();
        wrapper.eq("user_id", receiverId).eq("session_key", sessionKey);
        chatSession receiverSession = sessionMapper.selectOne(wrapper);
        if (receiverSession != null) {
            receiverSession.setLastMessage(displayContent);
            receiverSession.setLastTime(formatTime(new Date()));
            receiverSession.setUpdateTime(formatTime(new Date()));
            if (receiverSession.getUnread() == null) {
                receiverSession.setUnread(0);
            }
            receiverSession.setUnread(receiverSession.getUnread() + 1);
            sessionMapper.updateById(receiverSession);
        }
        
        Map<String, Object> result = new HashMap<>();
        result.put("id", message.getChatId());
        result.put("sessionKey", message.getSessionKey());
        result.put("senderId", message.getSenderId());
        result.put("receiverId", message.getReceiverId());
        result.put("content", message.getContent());
        result.put("type", message.getType());
        result.put("time", message.getCreateTime());
        return result;
    }

    @Override
    public List<Map<String, Object>> searchUser(String keyword) {
        QueryWrapper<user> wrapper = new QueryWrapper<>();
        wrapper.and(w -> w.eq("user_id", keyword).or().like("phone", keyword));
        List<user> users = userMapper.selectList(wrapper);
        
        List<Map<String, Object>> result = new ArrayList<>();
        for (user u : users) {
            Map<String, Object> map = new HashMap<>();
            map.put("userId", u.getUserId());
            map.put("nickName", u.getNickname());
            map.put("phone", u.getPhone());
            map.put("avatarUrl", u.getAvatar());
            result.add(map);
        }
        return result;
    }

    private String generateSessionKey(Integer userId, Integer targetId) {
        int min = Math.min(userId, targetId);
        int max = Math.max(userId, targetId);
        return "session_" + min + "_" + max;
    }

    private String formatTime(Date date) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        int h = cal.get(Calendar.HOUR_OF_DAY);
        int m = cal.get(Calendar.MINUTE);
        return String.format("%02d:%02d", h, m);
    }

}