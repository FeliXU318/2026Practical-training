package com.cqu.sell.service;

import com.cqu.sell.entity.member;
import com.baomidou.mybatisplus.extension.service.IService;
import java.util.Map;
import java.util.List;

public interface memberService extends IService<member> {
    member getMemberByUserId(Integer userId);
    member createMember(Integer userId);
    Map<String, Object> checkin(Integer userId);
    Map<String, Object> share(Integer userId);
    Map<String, Object> review(Integer userId, Integer orderId);
    Map<String, Object> usePoints(Integer userId, Integer points, Integer orderId);
    List<Map<String, Object>> getRecords(Integer userId, String type);
    Map<String, Object> consume(Integer userId, Double amount, Integer orderId);
}