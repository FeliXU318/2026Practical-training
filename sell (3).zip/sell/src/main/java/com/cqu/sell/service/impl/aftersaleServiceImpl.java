package com.cqu.sell.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.cqu.sell.entity.aftersale;
import com.cqu.sell.entity.order;
import com.cqu.sell.mapper.aftersaleMapper;
import com.cqu.sell.mapper.orderMapper;
import com.cqu.sell.service.aftersaleService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class aftersaleServiceImpl extends ServiceImpl<aftersaleMapper, aftersale> implements aftersaleService {

    private final orderMapper orderMapper;

    public aftersaleServiceImpl(orderMapper orderMapper) {
        this.orderMapper = orderMapper;
    }

    @Override
    public String apply(Integer userId, Integer orderId, String type, String reason, String reasonDesc, Double amount, String images, String description) {
        order order = orderMapper.selectById(orderId);
        if (order == null) {
            return null;
        }
        
        String afterSaleId = "AS" + System.currentTimeMillis();
        
        aftersale aftersale = new aftersale();
        aftersale.setAfterSaleId(afterSaleId);
        aftersale.setOrderId(orderId);
        aftersale.setOrderTitle(order.getTitle());
        aftersale.setOrderContent(order.getContent());
        aftersale.setOrderReward(order.getReward());
        aftersale.setType(type);
        aftersale.setTypeText(getTypeText(type));
        aftersale.setReason(reason);
        aftersale.setReasonText(getReasonText(reason));
        aftersale.setReasonDesc(reasonDesc);
        aftersale.setAmount(amount);
        aftersale.setActualRefund(amount);
        aftersale.setDescription(description);
        aftersale.setImages(images);
        aftersale.setStatus("applying");
        aftersale.setStatusText("申请中");
        aftersale.setCreateTime(System.currentTimeMillis());
        aftersale.setUpdateTime(System.currentTimeMillis());
        aftersale.setTimeline("[{\"time\":" + System.currentTimeMillis() + ",\"action\":\"apply\",\"text\":\"用户发起售后申请\"}]");
        
        this.save(aftersale);
        
        order.setStatusClass("status-sale");
        order.setOrderStatus("售后中");
        order.setAfterSaleId(afterSaleId);
        orderMapper.updateById(order);
        
        return afterSaleId;
    }

    @Override
    public List<aftersale> getList(Integer userId, String status) {
        QueryWrapper<aftersale> wrapper = new QueryWrapper<>();
        if (status != null && !status.isEmpty()) {
            wrapper.eq("status", status);
        }
        wrapper.orderByDesc("create_time");
        return baseMapper.selectList(wrapper);
    }

    @Override
    public aftersale getDetail(String afterSaleId) {
        QueryWrapper<aftersale> wrapper = new QueryWrapper<>();
        wrapper.eq("after_sale_id", afterSaleId);
        return baseMapper.selectOne(wrapper);
    }

    @Override
    public boolean cancel(String afterSaleId) {
        QueryWrapper<aftersale> wrapper = new QueryWrapper<>();
        wrapper.eq("after_sale_id", afterSaleId);
        aftersale aftersale = baseMapper.selectOne(wrapper);
        
        if (aftersale != null && "applying".equals(aftersale.getStatus())) {
            aftersale.setStatus("cancelled");
            aftersale.setStatusText("已撤销");
            aftersale.setUpdateTime(System.currentTimeMillis());
            this.updateById(aftersale);
            
            order order = orderMapper.selectById(aftersale.getOrderId());
            if (order != null) {
                order.setStatusClass("status-done");
                order.setOrderStatus("已完成");
                order.setAfterSaleId(null);
                orderMapper.updateById(order);
            }
            return true;
        }
        return false;
    }

    @Override
    public boolean ship(String afterSaleId, String company, String trackingNo) {
        QueryWrapper<aftersale> wrapper = new QueryWrapper<>();
        wrapper.eq("after_sale_id", afterSaleId);
        aftersale aftersale = baseMapper.selectOne(wrapper);
        
        if (aftersale != null) {
            aftersale.setCompany(company);
            aftersale.setTrackingNo(trackingNo);
            aftersale.setStatus("returning");
            aftersale.setStatusText("退货中");
            aftersale.setUpdateTime(System.currentTimeMillis());
            return this.updateById(aftersale);
        }
        return false;
    }

    private String getTypeText(String type) {
        return switch (type) {
            case "refund_return" -> "退货退款";
            case "exchange" -> "换货";
            default -> "仅退款";
        };
    }

    private String getReasonText(String reason) {
        return switch (reason) {
            case "damaged" -> "商品破损";
            case "wrong" -> "发错商品";
            case "missing" -> "商品缺失";
            case "description_not_match" -> "描述不符";
            case "other" -> "其他原因";
            default -> "商品质量问题";
        };
    }
}