package com.cqu.sell.service;

import com.cqu.sell.entity.run;
import com.baomidou.mybatisplus.extension.service.IService;
import java.util.List;

public interface runService extends IService<run> {
    List<run> getPendingTasks();
    run getTaskById(Integer id);
    run publishTask(Integer userId, String type, String reward, String content, String location, String color);
    boolean acceptTask(Integer userId, Integer id);
    boolean completeTask(Integer id, String deliveryPhoto, String deliveryDesc);
}