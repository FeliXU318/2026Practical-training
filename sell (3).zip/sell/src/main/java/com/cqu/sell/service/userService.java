package com.cqu.sell.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.cqu.sell.entity.user;
import com.baomidou.mybatisplus.extension.service.IService;
import java.util.List;

public interface userService extends IService<user>{
    boolean login(String phone,String password);

    List<user> findAll();

    boolean register(user user);

    boolean deleteUser(int user_id);

    boolean updatePassword(int user_id,String password);

    boolean updateNickname(int user_id,String nickname);

    user getUserByPhone(String phone);

    IPage<user> getUserPage(long current,long size);

}