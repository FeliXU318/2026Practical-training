package com.cqu.sell.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.cqu.sell.entity.merchant;
import com.cqu.sell.service.merchantService;
import java.util.HashMap;
import java.util.Map;
import java.util.List;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/merchant")
public class merchantController {

    @Autowired
    private merchantService merchantService;

    @GetMapping("/list")
    public Map<String,Object> list(@RequestParam String business_type){
        Map<String,Object> result=new HashMap<>();
        List<merchant> list=merchantService.findMerchantByType(business_type);
        boolean success = list.size()>0;
        result.put("success",success);
        if(success){
            result.put("data",list);
            result.put("count",list.size());
        }
        else{result.put("message","未找到商家");}
        return result;
    }

    @PostMapping("/addMerchant")
    public Map<String,Object> addMerchant(@RequestBody merchant merchant){
        Map<String,Object> result=new HashMap<>();
        boolean success=merchantService.addMerchant(merchant);
        result.put("success",success);
        if(success){
            result.put("message","新增商家成功");
        }
        else {result.put("message","新增商家失败");}
        return result;
    }

    @PutMapping("/deleteMerchant")
    public Map<String,Object> deleteMerchant(@RequestBody merchant merchant){
        Map<String,Object> result=new HashMap<>();
        int id=merchant.getMerchantId();
        boolean success=merchantService.deleteMerchant(id);
        result.put("success",success);
        if(success){
            result.put("message","注销成功");
        }
        else{result.put("message","注销失败");}
        return result;
    }

    @PutMapping("/updateMerchantName")
    public Map<String,Object> updateMerchantName(@RequestBody merchant merchant ,@RequestParam String merchant_name){
        Map<String,Object> result=new HashMap<>();
        int id=merchant.getMerchantId();
        boolean success=merchantService.updateMerchantName(id,merchant_name);
        result.put("success",success);
        if(success){
            result.put("message","修改成功");
        }
        else{result.put("message","修改失败");}
        return result;
    }

    @PutMapping("/updateContactPhone")
    public Map<String,Object> updateContactPhone(@RequestBody merchant merchant ,@RequestParam String phone){
        Map<String,Object> result=new HashMap<>();
        int id=merchant.getMerchantId();
        boolean success=merchantService.updateContactPhone(id,phone);
        result.put("success",success);
        if(success){
            result.put("message","修改成功");
        }
        else {result.put("message","修改失败");}
        return result;
    }

    @PutMapping("/updateStatus")
    public Map<String,Object> updateStatus(@RequestBody merchant merchant ,@RequestParam String status){
        Map<String,Object> result=new HashMap<>();
        int id=merchant.getMerchantId();
        boolean success = merchantService.updateStatus(id,status);
        result.put("success",success);
        if(success){
            result.put("message","修改成功");
        }
        else{result.put("message","当前已是该状态");}
        return result;
    }

    @PostMapping("/login")
    public Map<String, Object> login(@RequestBody Map<String, String> body) {
        return merchantService.login(body.get("account"), body.get("password"), 
            body.get("dormBuilding"), body.get("merchantCategory"));
    }

    @PostMapping("/wechat/login")
    public Map<String, Object> wechatLogin(@RequestBody Map<String, String> body) {
        return merchantService.wechatLogin(body.get("code"));
    }

    @PostMapping("/wechat/bind-phone")
    public Map<String, Object> bindPhone(@RequestBody Map<String, String> body) {
        return merchantService.bindPhone(
            body.get("loginToken"),
            body.get("phoneCode"),
            body.get("businessType"),
            body.get("merchantCategory")
        );
    }

}
