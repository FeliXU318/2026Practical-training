package com.cqu.sell.controller;

import com.cqu.sell.entity.run;
import com.cqu.sell.service.runService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/run")
public class runController {

    @Autowired
    private runService runService;

    @GetMapping("/list")
    public Map<String,Object> list(@RequestHeader(value = "Authorization") String token){
        Map<String,Object> result = new HashMap<>();
        
        List<run> tasks = runService.getPendingTasks();
        
        List<Map<String, Object>> list = new ArrayList<>();
        for (run task : tasks) {
            Map<String, Object> item = new HashMap<>();
            item.put("id", task.getId());
            item.put("type", task.getType());
            item.put("reward", task.getReward());
            item.put("content", task.getContent());
            item.put("user", task.getUser());
            item.put("avatar", task.getAvatar());
            item.put("location", task.getLocation());
            item.put("time", task.getTime());
            item.put("status", task.getStatus());
            item.put("statusClass", task.getStatusClass());
            item.put("color", task.getColor());
            list.add(item);
        }
        
        result.put("success", true);
        result.put("list", list);
        return result;
    }

    @GetMapping("/detail")
    public Map<String,Object> detail(@RequestHeader(value = "Authorization") String token, @RequestParam Integer id){
        Map<String,Object> result = new HashMap<>();
        
        run task = runService.getTaskById(id);
        if (task != null) {
            result.put("success", true);
            result.put("id", task.getId());
            result.put("type", task.getType());
            result.put("reward", task.getReward());
            result.put("content", task.getContent());
            result.put("user", task.getUser());
            result.put("avatar", task.getAvatar());
            result.put("location", task.getLocation());
            result.put("time", task.getTime());
            result.put("status", task.getStatus());
            result.put("statusClass", task.getStatusClass());
            result.put("color", task.getColor());
        } else {
            result.put("success", false);
            result.put("message", "任务不存在");
        }
        
        return result;
    }

    @PostMapping("/publish")
    public Map<String,Object> publish(@RequestHeader(value = "Authorization") String token, @RequestBody Map<String, Object> body){
        Map<String,Object> result = new HashMap<>();
        
        String userId = token.substring(7).replace("token_", "");
        int user_id = Integer.parseInt(userId);
        String type = String.valueOf(body.get("type"));
        String reward = String.valueOf(body.get("reward"));
        String content = String.valueOf(body.get("content"));
        String location = String.valueOf(body.get("location"));
        String color = String.valueOf(body.get("color"));
        
        run task = runService.publishTask(user_id, type, reward, content, location, color);
        
        Map<String, Object> taskMap = new HashMap<>();
        taskMap.put("id", task.getId());
        taskMap.put("status", task.getStatus());
        taskMap.put("statusClass", task.getStatusClass());
        
        result.put("success", true);
        result.put("message", "发布成功");
        result.put("task", taskMap);
        return result;
    }

    @PostMapping("/accept")
    public Map<String,Object> accept(@RequestHeader(value = "Authorization") String token, @RequestBody Map<String, Integer> body){
        Map<String,Object> result = new HashMap<>();
        
        String userId = token.substring(7).replace("token_", "");
        int user_id=Integer.parseInt(userId);
        Integer id = body.get("id");
        
        boolean success = runService.acceptTask(user_id, id);
        if (success) {
            result.put("success", true);
            result.put("message", "已接取");
        } else {
            result.put("success", false);
            result.put("message", "接取失败");
        }
        
        return result;
    }

    @PostMapping("/complete")
    public Map<String,Object> complete(@RequestHeader(value = "Authorization") String token, @RequestBody Map<String, Object> body){
        Map<String,Object> result = new HashMap<>();
        
        Integer id = (Integer) body.get("id");
        String deliveryPhoto = (String) body.get("deliveryPhoto");
        String deliveryDesc = (String) body.get("deliveryDesc");
        
        boolean success = runService.completeTask(id, deliveryPhoto, deliveryDesc);
        if (success) {
            result.put("success", true);
            result.put("message", "已完成");
        } else {
            result.put("success", false);
            result.put("message", "完成失败");
        }
        
        return result;
    }
}