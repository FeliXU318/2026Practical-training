package com.cqu.sell.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.cqu.sell.entity.member;
import com.cqu.sell.entity.memberRecord;
import com.cqu.sell.mapper.memberMapper;
import com.cqu.sell.mapper.memberRecordMapper;
import com.cqu.sell.service.memberService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class memberServiceImpl extends ServiceImpl<memberMapper, member> implements memberService {

    private final memberRecordMapper memberRecordMapper;

    public memberServiceImpl(memberRecordMapper memberRecordMapper) {
        this.memberRecordMapper = memberRecordMapper;
    }

    @Override
    public member getMemberByUserId(Integer userId) {
        QueryWrapper<member> wrapper = new QueryWrapper<>();
        wrapper.eq("user_id", userId);
        member member = baseMapper.selectOne(wrapper);
        if (member == null) {
            member = createMember(userId);
        }
        return member;
    }

    @Override
    public member createMember(Integer userId) {
        member member = new member();
        member.setUserId(userId);
        member.setLevel("normal");
        member.setLevelName("普通会员");
        member.setPoints(0);
        member.setGrowth(0);
        member.setTotalSpend(0.0);
        member.setCheckinDate("");
        member.setContinuousCheckin(0);
        this.save(member);
        return member;
    }

    @Override
    public Map<String, Object> checkin(Integer userId) {
        Map<String, Object> result = new HashMap<>();
        member member = getMemberByUserId(userId);
        String today = LocalDate.now().format(DateTimeFormatter.ISO_LOCAL_DATE);
        
        if (today.equals(member.getCheckinDate())) {
            result.put("success", false);
            result.put("message", "今日已签到");
            return result;
        }
        
        int pointsGain = 10;
        int growthGain = 5;
        int continuousCheckin = member.getContinuousCheckin() + 1;
        
        if (continuousCheckin > 7) {
            continuousCheckin = 1;
        }
        
        member.setCheckinDate(today);
        member.setContinuousCheckin(continuousCheckin);
        member.setPoints(member.getPoints() + pointsGain);
        member.setGrowth(member.getGrowth() + growthGain);
        this.updateById(member);
        
        saveRecord(userId, "points", pointsGain, member.getPoints(), "签到奖励", null);
        saveRecord(userId, "growth", growthGain, member.getGrowth(), "签到奖励", null);
        
        result.put("success", true);
        result.put("message", "签到成功");
        result.put("pointsGain", pointsGain);
        result.put("growthGain", growthGain);
        result.put("continuousCheckin", continuousCheckin);
        result.put("points", member.getPoints());
        result.put("growth", member.getGrowth());
        return result;
    }

    @Override
    public Map<String, Object> share(Integer userId) {
        Map<String, Object> result = new HashMap<>();
        member member = getMemberByUserId(userId);
        int pointsGain = 10;
        int growthGain = 3;
        
        member.setGrowth(member.getGrowth() + growthGain);
        member.setPoints(member.getPoints() + pointsGain);
        
        String oldLevel = member.getLevel();
        checkUpgrade(member);
        boolean isUpgrade = !oldLevel.equals(member.getLevel());
        
        this.updateById(member);
        
        saveRecord(userId, "points", pointsGain, member.getPoints(), "分享奖励", null);
        saveRecord(userId, "growth", growthGain, member.getGrowth(), "分享奖励", null);
        
        result.put("success", true);
        result.put("message", "分享奖励已领取");
        result.put("pointsGain", pointsGain);
        result.put("growthGain", growthGain);
        result.put("isUpgrade", isUpgrade);
        result.put("newLevel", member.getLevel());
        result.put("newLevelName", member.getLevelName());
        return result;
    }

    @Override
    public Map<String, Object> review(Integer userId, Integer orderId) {
        Map<String, Object> result = new HashMap<>();
        member member = getMemberByUserId(userId);
        
        QueryWrapper<memberRecord> wrapper = new QueryWrapper<>();
        wrapper.eq("user_id", userId)
               .eq("type", "points")
               .eq("order_id", orderId)
               .eq("reason", "评价奖励");
        if (memberRecordMapper.selectOne(wrapper) != null) {
            result.put("success", false);
            result.put("message", "该订单已评价过");
            return result;
        }
        
        int pointsGain = 5;
        member.setPoints(member.getPoints() + pointsGain);
        this.updateById(member);
        
        saveRecord(userId, "points", pointsGain, member.getPoints(), "评价奖励", orderId);
        
        result.put("success", true);
        result.put("message", "评价奖励已发放");
        result.put("pointsGain", pointsGain);
        return result;
    }

    @Override
    public Map<String, Object> usePoints(Integer userId, Integer points, Integer orderId) {
        Map<String, Object> result = new HashMap<>();
        member member = getMemberByUserId(userId);
        
        if (member.getPoints() < points) {
            result.put("success", false);
            result.put("message", "积分不足");
            return result;
        }
        
        member.setPoints(member.getPoints() - points);
        this.updateById(member);
        
        double discountAmount = points * 0.1;
        
        saveRecord(userId, "points", -points, member.getPoints(), "积分抵扣", orderId);
        
        result.put("success", true);
        result.put("message", "抵扣成功");
        result.put("discountAmount", discountAmount);
        result.put("points", member.getPoints());
        return result;
    }

    @Override
    public List<Map<String, Object>> getRecords(Integer userId, String type) {
        QueryWrapper<memberRecord> wrapper = new QueryWrapper<>();
        wrapper.eq("user_id", userId);
        if (type != null && !type.isEmpty()) {
            wrapper.eq("type", type);
        }
        wrapper.orderByDesc("time");
        
        List<memberRecord> records = memberRecordMapper.selectList(wrapper);
        return records.stream().map(r -> {
            Map<String, Object> map = new HashMap<>();
            map.put("id", r.getRecordId());
            map.put("type", r.getType());
            map.put("change", r.getChange());
            map.put("balance", r.getBalance());
            map.put("reason", r.getReason());
            map.put("orderId", r.getOrderId());
            map.put("time", r.getTime());
            return map;
        }).toList();
    }

    @Override
    public Map<String, Object> consume(Integer userId, Double amount, Integer orderId) {
        Map<String, Object> result = new HashMap<>();
        member member = getMemberByUserId(userId);
        
        QueryWrapper<memberRecord> wrapper = new QueryWrapper<>();
        wrapper.eq("user_id", userId)
               .eq("type", "points")
               .eq("order_id", orderId)
               .eq("reason", "消费获得");
        if (memberRecordMapper.selectOne(wrapper) != null) {
            result.put("success", true);
            result.put("changed", false);
            result.put("message", "该订单已发放过积分");
            return result;
        }
        
        double multiplier = getMultiplier(member.getLevel());
        int pointsGain = (int) (amount * multiplier);
        int growthGain = amount.intValue();
        
        member.setPoints(member.getPoints() + pointsGain);
        member.setGrowth(member.getGrowth() + growthGain);
        member.setTotalSpend(member.getTotalSpend() + amount);
        
        String oldLevel = member.getLevel();
        checkUpgrade(member);
        boolean isUpgrade = !oldLevel.equals(member.getLevel());
        
        this.updateById(member);
        
        saveRecord(userId, "points", pointsGain, member.getPoints(), "消费获得", orderId);
        saveRecord(userId, "growth", growthGain, member.getGrowth(), "消费获得", orderId);
        
        result.put("success", true);
        result.put("pointsGain", pointsGain);
        result.put("growthGain", growthGain);
        result.put("points", member.getPoints());
        result.put("growth", member.getGrowth());
        result.put("changed", true);
        result.put("isUpgrade", isUpgrade);
        result.put("newLevel", member.getLevel());
        return result;
    }

    private double getMultiplier(String level) {
        return switch (level) {
            case "gold" -> 2;
            case "diamond" -> 3;
            default -> 1;
        };
    }

    private void checkUpgrade(member member) {
        int growth = member.getGrowth();
        if (growth >= 5000) {
            member.setLevel("diamond");
            member.setLevelName("钻石会员");
        } else if (growth >= 2000) {
            member.setLevel("gold");
            member.setLevelName("金卡会员");
        } else if (growth >= 500) {
            member.setLevel("silver");
            member.setLevelName("银卡会员");
        }
    }

    private void saveRecord(Integer userId, String type, Integer change, Integer balance, String reason, Integer orderId) {
        memberRecord record = new memberRecord();
        record.setRecordId(System.currentTimeMillis() + "_" + type);
        record.setUserId(userId);
        record.setType(type);
        record.setChange(change);
        record.setBalance(balance);
        record.setReason(reason);
        record.setOrderId(orderId);
        record.setTime(java.time.LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));
        memberRecordMapper.insert(record);
    }
}