package com.cqu.sell.controller;

import com.cqu.sell.entity.aftersale;
import com.cqu.sell.mapper.aftersaleMapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/merchant/aftersales")
public class merchantAftersaleController {

    @Autowired
    private aftersaleMapper aftersaleMapper;

    @GetMapping
    public Map<String, Object> list(@RequestParam String businessType) {
        Map<String, Object> result = new HashMap<>();
        QueryWrapper<aftersale> wrapper = new QueryWrapper<>();
        wrapper.orderByDesc("id");
        
        List<aftersale> aftersales = aftersaleMapper.selectList(wrapper);
        
        List<Map<String, Object>> list = new ArrayList<>();
        for (aftersale a : aftersales) {
            Map<String, Object> item = new HashMap<>();
            item.put("id", "A" + a.getId());
            item.put("orderId", a.getOrderId());
            item.put("orderNo", "O" + String.format("%010d", a.getOrderId()));
            item.put("businessType", businessType);
            item.put("customer", "用户");
            item.put("type", a.getType());
            item.put("status", a.getStatus() != null ? a.getStatus() : "待处理");
            item.put("content", a.getDescription());
            item.put("result", a.getReason());
            item.put("createdAt", a.getCreateTime() != null ? new java.util.Date(a.getCreateTime()).toString() : "");
            list.add(item);
        }
        
        result.put("code", 0);
        result.put("message", "ok");
        result.put("data", list);
        return result;
    }

    @PostMapping("/result")
    public Map<String, Object> handle(@RequestBody Map<String, Object> body) {
        Map<String, Object> result = new HashMap<>();
        String id = (String) body.get("id");
        String resultText = (String) body.get("result");
        
        Integer aftersaleId = Integer.parseInt(id.substring(1));
        aftersale a = aftersaleMapper.selectById(aftersaleId);
        
        if (a != null) {
            a.setReason(resultText);
            a.setStatus("已处理");
            aftersaleMapper.updateById(a);
            
            Map<String, Object> data = new HashMap<>();
            data.put("id", id);
            data.put("status", "已处理");
            data.put("result", resultText);
            
            result.put("code", 0);
            result.put("message", "ok");
            result.put("data", data);
        } else {
            result.put("code", 1);
            result.put("message", "售后记录不存在");
        }
        
        return result;
    }
}