package com.cqu.sell.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.cqu.sell.entity.chatSession;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface chatSessionMapper extends BaseMapper<chatSession> {
}