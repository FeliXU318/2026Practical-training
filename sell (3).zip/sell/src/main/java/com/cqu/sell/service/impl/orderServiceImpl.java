package com.cqu.sell.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.cqu.sell.entity.order;
import com.cqu.sell.mapper.orderMapper;
import com.cqu.sell.service.orderService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class orderServiceImpl extends ServiceImpl<orderMapper, order> implements orderService {

    @Override
    public List<order> findUserOrder(String userId){
        QueryWrapper<order> wrapper = new QueryWrapper<>();
        wrapper.eq("user_id",userId);
        return baseMapper.selectList(wrapper);
    }

    @Override
    public List<order> findMerchantOrder(String merchantId){
        QueryWrapper<order> wrapper = new QueryWrapper<>();
        wrapper.eq("merchant_id",merchantId);
        return baseMapper.selectList(wrapper);
    }

    @Override
    public boolean addOrder(order order) {
        return this.save(order);
    }

    @Override
    public boolean deleteOrder(int order_id){
        return this.removeById(order_id);
    }

    @Override
    public boolean updateOrderAddress(int order_id, String address){
        order o = this.getById(order_id);
        String old_address = o.getAddress();
        if(!old_address.equals(address)){
            o.setAddress(address);
            this.updateById(o);
            return true;
        }
        return false;
    }

    @Override
    public order getOrderById(int order_id){
        QueryWrapper<order> wrapper = new QueryWrapper<>();
        wrapper.eq("order_id",order_id);
        return baseMapper.selectOne(wrapper);
    }

    @Override
    public IPage<order> getOrderPage(long current, long size){
        Page<order> page=new Page<>(current,size);
        QueryWrapper<order> wrapper=new QueryWrapper<>();
        wrapper.orderByAsc("id");
        return this.page(page,wrapper);
    }

    @Override
    public boolean updateOrderStatus(int order_id, String status){
        order o = this.getById(order_id);
        String old_status = o.getOrderStatus();
        if(!old_status.equals(status)){
            o.setOrderStatus(status);
            this.updateById(o);
            return true;
        }
        return false;
    }



}
