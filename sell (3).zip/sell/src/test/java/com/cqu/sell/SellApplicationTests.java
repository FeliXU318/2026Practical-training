package com.cqu.sell;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SellApplicationTests {

    @Test
    void contextLoads() {
    }

}
